package com.campus.share.domain.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CertificationReviewRequest {
    @NotBlank(message = "请传入审核结果")
    private String status;

    private String remark;
}
