package com.campus.share.service;

import com.campus.share.common.AuthContext;
import com.campus.share.common.BusinessException;
import com.campus.share.common.PasswordCodec;
import com.campus.share.domain.request.AuthLoginRequest;
import com.campus.share.domain.request.AuthRegisterRequest;
import com.campus.share.domain.response.AuthSessionResponse;
import com.campus.share.domain.response.UserProfileResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final JdbcTemplate jdbcTemplate;
    private final SessionService sessionService;
    private final UserService userService;

    public AuthSessionResponse register(AuthRegisterRequest request) {
        ensureUnique(request.getStudentId(), request.getPhone());
        jdbcTemplate.update(
                "insert into users(student_id, phone, password_hash, nickname) values (?, ?, ?, ?)",
                request.getStudentId(),
                request.getPhone(),
                PasswordCodec.encode(request.getPassword()),
                request.getNickname()
        );
        Long userId = jdbcTemplate.queryForObject(
                "select id from users where student_id = ?",
                Long.class,
                request.getStudentId()
        );
        if (userId == null) {
            throw new BusinessException("注册失败，请稍后重试");
        }
        UserProfileResponse profile = userService.getUserProfile(userId);
        String token = sessionService.createUserSession(userId, profile.getNickname());
        return new AuthSessionResponse(token, "USER", profile);
    }

    public AuthSessionResponse login(AuthLoginRequest request) {
        List<UserLoginRow> rows = jdbcTemplate.query(
                "select id, password_hash as passwordHash, nickname, is_disabled as disabled from users " +
                        "where student_id = ? or phone = ?",
                (rs, rowNum) -> {
                    UserLoginRow row = new UserLoginRow();
                    row.setId(rs.getLong("id"));
                    row.setPasswordHash(rs.getString("passwordHash"));
                    row.setNickname(rs.getString("nickname"));
                    row.setDisabled(rs.getInt("disabled") == 1);
                    return row;
                },
                request.getAccount(),
                request.getAccount()
        );
        if (rows.isEmpty()) {
            throw new BusinessException("账号或密码错误");
        }
        UserLoginRow row = rows.getFirst();
        if (Boolean.TRUE.equals(row.getDisabled())) {
            throw new BusinessException("当前账号已被停用，请联系管理员");
        }
        if (!PasswordCodec.matches(request.getPassword(), row.getPasswordHash())) {
            throw new BusinessException("账号或密码错误");
        }
        String token = sessionService.createUserSession(row.getId(), row.getNickname());
        return new AuthSessionResponse(token, "USER", userService.getUserProfile(row.getId()));
    }

    public void logout() {
        AuthContext.LoginSession session = sessionService.requireLogin();
        sessionService.remove(session.getToken());
    }

    public UserProfileResponse currentUser() {
        AuthContext.LoginSession session = sessionService.requireUser();
        return userService.getUserProfile(session.getPrincipalId());
    }

    private void ensureUnique(String studentId, String phone) {
        Integer studentCount = jdbcTemplate.queryForObject(
                "select count(*) from users where student_id = ?",
                Integer.class,
                studentId
        );
        if (studentCount != null && studentCount > 0) {
            throw new BusinessException("该学号已注册");
        }
        Integer phoneCount = jdbcTemplate.queryForObject(
                "select count(*) from users where phone = ?",
                Integer.class,
                phone
        );
        if (phoneCount != null && phoneCount > 0) {
            throw new BusinessException("该手机号已注册");
        }
    }

    @lombok.Data
    private static class UserLoginRow {
        private Long id;
        private String passwordHash;
        private String nickname;
        private Boolean disabled;
    }
}
