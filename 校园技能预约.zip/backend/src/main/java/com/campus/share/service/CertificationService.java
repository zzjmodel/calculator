package com.campus.share.service;

import com.campus.share.common.AuthContext;
import com.campus.share.common.BusinessException;
import com.campus.share.domain.request.CertificationReviewRequest;
import com.campus.share.domain.request.CertificationSubmitRequest;
import com.campus.share.domain.response.CertificationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CertificationService {

    private final JdbcTemplate jdbcTemplate;
    private final SessionService sessionService;
    private final NotificationService notificationService;

    public CertificationResponse submit(CertificationSubmitRequest request) {
        AuthContext.LoginSession session = sessionService.requireUser();
        Integer pendingCount = jdbcTemplate.queryForObject(
                "select count(*) from certification_requests where user_id = ? and status = 'SUBMITTED'",
                Integer.class,
                session.getPrincipalId()
        );
        if (pendingCount != null && pendingCount > 0) {
            throw new BusinessException("你有待审核的认证申请，请勿重复提交");
        }
        jdbcTemplate.update(
                "insert into certification_requests(user_id, real_name, student_card_image, status) values (?, ?, ?, 'SUBMITTED')",
                session.getPrincipalId(),
                request.getRealName(),
                request.getStudentCardImage()
        );
        jdbcTemplate.update(
                "update users set certification_status = 'SUBMITTED', updated_at = current_timestamp where id = ?",
                session.getPrincipalId()
        );
        return getMyLatest();
    }

    public CertificationResponse getMyLatest() {
        AuthContext.LoginSession session = sessionService.requireUser();
        return jdbcTemplate.query(
                        "select c.id, c.user_id as userId, u.nickname as userNickname, c.real_name as realName, c.student_card_image as studentCardImage, " +
                                "c.status, c.remark, c.submitted_at as submittedAt, c.reviewed_at as reviewedAt " +
                                "from certification_requests c join users u on c.user_id = u.id where c.user_id = ? order by c.id desc limit 1",
                        (rs, rowNum) -> {
                            CertificationResponse response = new CertificationResponse();
                            response.setId(rs.getLong("id"));
                            response.setUserId(rs.getLong("userId"));
                            response.setUserNickname(rs.getString("userNickname"));
                            response.setRealName(rs.getString("realName"));
                            response.setStudentCardImage(rs.getString("studentCardImage"));
                            response.setStatus(rs.getString("status"));
                            response.setRemark(rs.getString("remark"));
                            response.setSubmittedAt(rs.getTimestamp("submittedAt").toLocalDateTime());
                            if (rs.getTimestamp("reviewedAt") != null) {
                                response.setReviewedAt(rs.getTimestamp("reviewedAt").toLocalDateTime());
                            }
                            return response;
                        },
                        session.getPrincipalId())
                .stream()
                .findFirst()
                .orElse(null);
    }

    public List<CertificationResponse> listAll() {
        sessionService.requireAdmin();
        return jdbcTemplate.query(
                "select c.id, c.user_id as userId, u.nickname as userNickname, c.real_name as realName, c.student_card_image as studentCardImage, " +
                        "c.status, c.remark, c.submitted_at as submittedAt, c.reviewed_at as reviewedAt " +
                        "from certification_requests c join users u on c.user_id = u.id order by c.id desc",
                (rs, rowNum) -> {
                    CertificationResponse response = new CertificationResponse();
                    response.setId(rs.getLong("id"));
                    response.setUserId(rs.getLong("userId"));
                    response.setUserNickname(rs.getString("userNickname"));
                    response.setRealName(rs.getString("realName"));
                    response.setStudentCardImage(rs.getString("studentCardImage"));
                    response.setStatus(rs.getString("status"));
                    response.setRemark(rs.getString("remark"));
                    response.setSubmittedAt(rs.getTimestamp("submittedAt").toLocalDateTime());
                    if (rs.getTimestamp("reviewedAt") != null) {
                        response.setReviewedAt(rs.getTimestamp("reviewedAt").toLocalDateTime());
                    }
                    return response;
                }
        );
    }

    public CertificationResponse review(Long certificationId, CertificationReviewRequest request) {
        sessionService.requireAdmin();
        if (!List.of("APPROVED", "REJECTED").contains(request.getStatus())) {
            throw new BusinessException("审核结果不合法");
        }
        List<Long> userIds = jdbcTemplate.query(
                "select user_id from certification_requests where id = ?",
                (rs, rowNum) -> rs.getLong("user_id"),
                certificationId
        );
        if (userIds.isEmpty()) {
            throw new BusinessException("认证记录不存在");
        }
        jdbcTemplate.update(
                "update certification_requests set status = ?, remark = ?, reviewed_at = current_timestamp where id = ?",
                request.getStatus(),
                request.getRemark(),
                certificationId
        );
        jdbcTemplate.update(
                "update users set certification_status = ?, updated_at = current_timestamp where id = ?",
                request.getStatus(),
                userIds.getFirst()
        );
        notificationService.create(
                userIds.getFirst(),
                "CERTIFICATION",
                "实名认证结果已更新",
                "你的实名认证申请已被处理，当前状态为：" + ("APPROVED".equals(request.getStatus()) ? "已通过" : "已驳回")
        );
        return listAll().stream()
                .filter(item -> item.getId().equals(certificationId))
                .findFirst()
                .orElseThrow(() -> new BusinessException("认证记录不存在"));
    }
}
