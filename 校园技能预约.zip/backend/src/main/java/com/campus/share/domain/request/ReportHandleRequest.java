package com.campus.share.domain.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ReportHandleRequest {
    @NotBlank(message = "请填写处理结果")
    private String handleResult;
}
