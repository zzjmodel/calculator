package com.campus.share.service;

import com.campus.share.common.AuthContext;
import com.campus.share.domain.response.NotificationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final JdbcTemplate jdbcTemplate;
    private final SessionService sessionService;

    public void create(Long userId, String type, String title, String content) {
        jdbcTemplate.update(
                "insert into notifications(user_id, type, title, content, is_read) values (?, ?, ?, ?, 0)",
                userId,
                type,
                title,
                content
        );
    }

    public List<NotificationResponse> myNotifications() {
        AuthContext.LoginSession session = sessionService.requireUser();
        return jdbcTemplate.query(
                "select id, type, title, content, is_read as isRead, created_at as createdAt from notifications where user_id = ? order by created_at desc limit 20",
                (rs, rowNum) -> {
                    NotificationResponse response = new NotificationResponse();
                    response.setId(rs.getLong("id"));
                    response.setType(rs.getString("type"));
                    response.setTitle(rs.getString("title"));
                    response.setContent(rs.getString("content"));
                    response.setRead(rs.getInt("isRead") == 1);
                    response.setCreatedAt(rs.getTimestamp("createdAt").toLocalDateTime());
                    return response;
                },
                session.getPrincipalId()
        );
    }

    public void markAllRead() {
        AuthContext.LoginSession session = sessionService.requireUser();
        jdbcTemplate.update(
                "update notifications set is_read = 1 where user_id = ? and is_read = 0",
                session.getPrincipalId()
        );
    }
}
