package com.campus.share.domain.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StatsItemResponse {
    private String key;
    private String label;
    private long total;
}
