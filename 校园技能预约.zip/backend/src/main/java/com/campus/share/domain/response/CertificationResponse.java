package com.campus.share.domain.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CertificationResponse {
    private Long id;
    private Long userId;
    private String userNickname;
    private String realName;
    private String studentCardImage;
    private String status;
    private String remark;
    private LocalDateTime submittedAt;
    private LocalDateTime reviewedAt;
}
