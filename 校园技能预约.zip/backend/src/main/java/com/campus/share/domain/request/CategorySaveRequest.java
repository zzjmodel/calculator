package com.campus.share.domain.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CategorySaveRequest {
    @NotBlank(message = "请输入分类名称")
    private String name;

    @NotBlank(message = "请选择分类类型")
    private String type;

    @NotNull(message = "请填写排序值")
    private Integer sortOrder;
}
