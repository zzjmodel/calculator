package com.campus.share.domain.response;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
public class HomeResponse {
    private List<AnnouncementResponse> announcements;
    private List<ListingResponse> featuredListings;
    private Map<String, Long> stats;
}
