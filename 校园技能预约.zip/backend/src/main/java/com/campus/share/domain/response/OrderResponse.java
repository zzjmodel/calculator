package com.campus.share.domain.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class OrderResponse {
    private Long id;
    private Long listingId;
    private String listingTitle;
    private String listingType;
    private Long buyerId;
    private Long sellerId;
    private String buyerNickname;
    private String sellerNickname;
    private String status;
    private String note;
    private String tradeLocation;
    private String contactPhone;
    private String handoffMethod;
    private String pickupCode;
    private Boolean offlinePaid;
    private LocalDateTime createdAt;
    private LocalDateTime confirmedAt;
    private LocalDateTime completedAt;
}
