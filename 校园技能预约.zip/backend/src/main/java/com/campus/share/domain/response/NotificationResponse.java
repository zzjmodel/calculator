package com.campus.share.domain.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class NotificationResponse {
    private Long id;
    private String type;
    private String title;
    private String content;
    private Boolean read;
    private LocalDateTime createdAt;
}
