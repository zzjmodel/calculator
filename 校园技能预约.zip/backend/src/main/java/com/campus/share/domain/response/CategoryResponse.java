package com.campus.share.domain.response;

import lombok.Data;

@Data
public class CategoryResponse {
    private Long id;
    private String name;
    private String type;
    private Boolean enabled;
    private Integer sortOrder;
}
