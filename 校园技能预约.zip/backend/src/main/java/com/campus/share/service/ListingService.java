package com.campus.share.service;

import com.campus.share.common.AuthContext;
import com.campus.share.common.BusinessException;
import com.campus.share.domain.request.ListingCreateRequest;
import com.campus.share.domain.request.ListingQueryRequest;
import com.campus.share.domain.response.ListingResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ListingService {

    private final JdbcTemplate jdbcTemplate;
    private final SessionService sessionService;

    public ListingResponse create(ListingCreateRequest request) {
        AuthContext.LoginSession session = sessionService.requireUser();
        validateType(request.getType());
        jdbcTemplate.update(
                "insert into listings(user_id, type, category_id, title, description, images, price, stock, location, contact, appointment_time, status) " +
                        "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PUBLISHED')",
                session.getPrincipalId(),
                request.getType(),
                request.getCategoryId(),
                request.getTitle(),
                request.getDescription(),
                request.getImages(),
                request.getPrice(),
                request.getStock(),
                request.getLocation(),
                request.getContact(),
                request.getAppointmentTime()
        );
        Long id = jdbcTemplate.queryForObject("select max(id) from listings", Long.class);
        return getDetail(id);
    }

    public List<ListingResponse> list(ListingQueryRequest request) {
        StringBuilder sql = new StringBuilder(
                "select l.id, l.type, l.category_id as categoryId, c.name as categoryName, l.user_id as userId, u.nickname as userNickname, " +
                        "l.title, l.description, l.images, l.price, l.stock, l.location, l.contact, l.appointment_time as appointmentTime, " +
                        "l.status, l.view_count as viewCount, l.created_at as createdAt, l.updated_at as updatedAt " +
                        "from listings l join users u on l.user_id = u.id left join categories c on l.category_id = c.id where 1 = 1"
        );
        List<Object> args = new ArrayList<>();
        if (request.getKeyword() != null && !request.getKeyword().isBlank()) {
            sql.append(" and (l.title like ? or l.description like ?)");
            args.add("%" + request.getKeyword().trim() + "%");
            args.add("%" + request.getKeyword().trim() + "%");
        }
        if (request.getType() != null && !request.getType().isBlank()) {
            sql.append(" and l.type = ?");
            args.add(request.getType());
        }
        if (request.getCategoryId() != null) {
            sql.append(" and l.category_id = ?");
            args.add(request.getCategoryId());
        }
        String status = request.getStatus();
        if (status == null || status.isBlank()) {
            sql.append(" and l.status = 'PUBLISHED'");
        } else {
            sql.append(" and l.status = ?");
            args.add(status);
        }
        sql.append(" order by l.created_at desc");
        return jdbcTemplate.query(sql.toString(), this::mapListing, args.toArray());
    }

    public List<ListingResponse> myListings() {
        AuthContext.LoginSession session = sessionService.requireUser();
        return jdbcTemplate.query(
                "select l.id, l.type, l.category_id as categoryId, c.name as categoryName, l.user_id as userId, u.nickname as userNickname, " +
                        "l.title, l.description, l.images, l.price, l.stock, l.location, l.contact, l.appointment_time as appointmentTime, " +
                        "l.status, l.view_count as viewCount, l.created_at as createdAt, l.updated_at as updatedAt " +
                        "from listings l join users u on l.user_id = u.id left join categories c on l.category_id = c.id where l.user_id = ? order by l.created_at desc",
                this::mapListing,
                session.getPrincipalId()
        );
    }

    public List<ListingResponse> adminList(String status) {
        sessionService.requireAdmin();
        StringBuilder sql = new StringBuilder(
                "select l.id, l.type, l.category_id as categoryId, c.name as categoryName, l.user_id as userId, u.nickname as userNickname, " +
                        "l.title, l.description, l.images, l.price, l.stock, l.location, l.contact, l.appointment_time as appointmentTime, " +
                        "l.status, l.view_count as viewCount, l.created_at as createdAt, l.updated_at as updatedAt " +
                        "from listings l join users u on l.user_id = u.id left join categories c on l.category_id = c.id where 1 = 1"
        );
        List<Object> args = new ArrayList<>();
        if (status != null && !status.isBlank()) {
            sql.append(" and l.status = ?");
            args.add(status);
        }
        sql.append(" order by l.created_at desc");
        return jdbcTemplate.query(sql.toString(), this::mapListing, args.toArray());
    }

    public ListingResponse adminChangeStatus(Long id, String status) {
        sessionService.requireAdmin();
        if (!List.of("PUBLISHED", "OFFLINE").contains(status)) {
            throw new BusinessException("状态不合法");
        }
        Integer count = jdbcTemplate.queryForObject("select count(*) from listings where id = ?", Integer.class, id);
        if (count == null || count == 0) {
            throw new BusinessException("信息不存在");
        }
        jdbcTemplate.update(
                "update listings set status = ?, updated_at = current_timestamp where id = ?",
                status,
                id
        );
        return getDetailWithoutIncrement(id);
    }

    public ListingResponse getDetail(Long id) {
        List<ListingResponse> list = jdbcTemplate.query(
                "select l.id, l.type, l.category_id as categoryId, c.name as categoryName, l.user_id as userId, u.nickname as userNickname, " +
                        "l.title, l.description, l.images, l.price, l.stock, l.location, l.contact, l.appointment_time as appointmentTime, " +
                        "l.status, l.view_count as viewCount, l.created_at as createdAt, l.updated_at as updatedAt " +
                        "from listings l join users u on l.user_id = u.id left join categories c on l.category_id = c.id where l.id = ?",
                this::mapListing,
                id
        );
        if (list.isEmpty()) {
            throw new BusinessException("信息不存在");
        }
        jdbcTemplate.update("update listings set view_count = view_count + 1 where id = ?", id);
        ListingResponse response = list.getFirst();
        response.setViewCount(response.getViewCount() == null ? 1 : response.getViewCount() + 1);
        return response;
    }

    public ListingResponse update(Long id, ListingCreateRequest request) {
        AuthContext.LoginSession session = sessionService.requireUser();
        ensureOwner(id, session.getPrincipalId());
        validateType(request.getType());
        jdbcTemplate.update(
                "update listings set type = ?, category_id = ?, title = ?, description = ?, images = ?, price = ?, stock = ?, " +
                        "location = ?, contact = ?, appointment_time = ?, updated_at = current_timestamp where id = ?",
                request.getType(),
                request.getCategoryId(),
                request.getTitle(),
                request.getDescription(),
                request.getImages(),
                request.getPrice(),
                request.getStock(),
                request.getLocation(),
                request.getContact(),
                request.getAppointmentTime(),
                id
        );
        return getDetailWithoutIncrement(id);
    }

    public ListingResponse changeStatus(Long id, String status) {
        AuthContext.LoginSession session = sessionService.requireUser();
        ensureOwner(id, session.getPrincipalId());
        if (!List.of("PUBLISHED", "OFFLINE").contains(status)) {
            throw new BusinessException("状态不合法");
        }
        jdbcTemplate.update(
                "update listings set status = ?, updated_at = current_timestamp where id = ?",
                status,
                id
        );
        return getDetailWithoutIncrement(id);
    }

    public List<ListingResponse> featured() {
        return jdbcTemplate.query(
                "select l.id, l.type, l.category_id as categoryId, c.name as categoryName, l.user_id as userId, u.nickname as userNickname, " +
                        "l.title, l.description, l.images, l.price, l.stock, l.location, l.contact, l.appointment_time as appointmentTime, " +
                        "l.status, l.view_count as viewCount, l.created_at as createdAt, l.updated_at as updatedAt " +
                        "from listings l join users u on l.user_id = u.id left join categories c on l.category_id = c.id " +
                        "where l.status = 'PUBLISHED' order by l.view_count desc, l.created_at desc limit 6",
                this::mapListing
        );
    }

    private void ensureOwner(Long listingId, Long userId) {
        Integer count = jdbcTemplate.queryForObject(
                "select count(*) from listings where id = ? and user_id = ?",
                Integer.class,
                listingId,
                userId
        );
        if (count == null || count == 0) {
            throw new BusinessException("你无权操作这条信息");
        }
    }

    private void validateType(String type) {
        if (!List.of("SKILL", "ITEM", "HELP").contains(type)) {
            throw new BusinessException("信息类型不正确");
        }
    }

    private ListingResponse getDetailWithoutIncrement(Long id) {
        return jdbcTemplate.query(
                        "select l.id, l.type, l.category_id as categoryId, c.name as categoryName, l.user_id as userId, u.nickname as userNickname, " +
                                "l.title, l.description, l.images, l.price, l.stock, l.location, l.contact, l.appointment_time as appointmentTime, " +
                                "l.status, l.view_count as viewCount, l.created_at as createdAt, l.updated_at as updatedAt " +
                                "from listings l join users u on l.user_id = u.id left join categories c on l.category_id = c.id where l.id = ?",
                        this::mapListing,
                        id)
                .stream()
                .findFirst()
                .orElseThrow(() -> new BusinessException("信息不存在"));
    }

    private ListingResponse mapListing(java.sql.ResultSet rs, int rowNum) throws java.sql.SQLException {
        ListingResponse response = new ListingResponse();
        response.setId(rs.getLong("id"));
        response.setType(rs.getString("type"));
        response.setCategoryId(rs.getObject("categoryId", Long.class));
        response.setCategoryName(rs.getString("categoryName"));
        response.setUserId(rs.getLong("userId"));
        response.setUserNickname(rs.getString("userNickname"));
        response.setTitle(rs.getString("title"));
        response.setDescription(rs.getString("description"));
        response.setImages(rs.getString("images"));
        response.setPrice(rs.getBigDecimal("price"));
        response.setStock(rs.getInt("stock"));
        response.setLocation(rs.getString("location"));
        response.setContact(rs.getString("contact"));
        response.setAppointmentTime(rs.getString("appointmentTime"));
        response.setStatus(rs.getString("status"));
        response.setViewCount(rs.getInt("viewCount"));
        response.setCreatedAt(rs.getTimestamp("createdAt").toLocalDateTime());
        response.setUpdatedAt(rs.getTimestamp("updatedAt").toLocalDateTime());
        return response;
    }
}
