package com.campus.share.domain.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CertificationSubmitRequest {
    @NotBlank(message = "请输入真实姓名")
    private String realName;

    @NotBlank(message = "请填写学生证图片地址")
    private String studentCardImage;
}
