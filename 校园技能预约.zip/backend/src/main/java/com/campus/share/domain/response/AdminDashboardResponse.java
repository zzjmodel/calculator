package com.campus.share.domain.response;

import lombok.Data;

import java.util.List;

@Data
public class AdminDashboardResponse {
    private long userCount;
    private long listingCount;
    private long orderCount;
    private long completedOrderCount;
    private long pendingCertificationCount;
    private long pendingReportCount;
    private List<StatsItemResponse> listingTypeStats;
    private List<StatsItemResponse> orderStatusStats;
    private List<StatsItemResponse> hotCategoryStats;
    private List<StatsTrendPointResponse> recentListingTrend;
    private List<StatsTrendPointResponse> recentOrderTrend;
}
