package com.campus.share.domain.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class AdminLoginRequest {
    @NotBlank(message = "请输入管理员账号")
    private String username;

    @NotBlank(message = "请输入管理员密码")
    private String password;
}
