package com.campus.share.domain.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ReviewCreateRequest {
    @NotNull(message = "请传入订单编号")
    private Long orderId;

    @NotNull(message = "请填写评分")
    @Min(value = 1, message = "评分最小为 1 分")
    @Max(value = 5, message = "评分最大为 5 分")
    private Integer rating;

    @NotBlank(message = "请填写评价内容")
    private String content;
}
