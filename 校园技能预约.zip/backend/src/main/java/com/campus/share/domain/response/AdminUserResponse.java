package com.campus.share.domain.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AdminUserResponse {
    private Long id;
    private String studentId;
    private String phone;
    private String nickname;
    private String department;
    private String gradeLevel;
    private Boolean disabled;
    private String certificationStatus;
    private LocalDateTime createdAt;
}
