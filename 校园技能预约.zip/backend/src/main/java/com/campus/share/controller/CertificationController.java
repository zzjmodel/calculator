package com.campus.share.controller;

import com.campus.share.common.ApiResponse;
import com.campus.share.domain.request.CertificationReviewRequest;
import com.campus.share.domain.request.CertificationSubmitRequest;
import com.campus.share.domain.response.CertificationResponse;
import com.campus.share.service.CertificationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class CertificationController {

    private final CertificationService certificationService;

    @PostMapping("/api/certifications")
    public ApiResponse<CertificationResponse> submit(@Valid @RequestBody CertificationSubmitRequest request) {
        return ApiResponse.ok("认证申请已提交", certificationService.submit(request));
    }

    @GetMapping("/api/certifications/my")
    public ApiResponse<CertificationResponse> myLatest() {
        return ApiResponse.ok(certificationService.getMyLatest());
    }

    @GetMapping("/api/admin/certifications")
    public ApiResponse<List<CertificationResponse>> listAll() {
        return ApiResponse.ok(certificationService.listAll());
    }

    @PostMapping("/api/admin/certifications/{id}/review")
    public ApiResponse<CertificationResponse> review(@PathVariable Long id, @Valid @RequestBody CertificationReviewRequest request) {
        return ApiResponse.ok("审核已完成", certificationService.review(id, request));
    }
}
