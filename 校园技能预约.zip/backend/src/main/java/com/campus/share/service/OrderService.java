package com.campus.share.service;

import com.campus.share.common.AuthContext;
import com.campus.share.common.BusinessException;
import com.campus.share.domain.request.OrderCompleteRequest;
import com.campus.share.domain.request.OrderCreateRequest;
import com.campus.share.domain.response.OrderResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final JdbcTemplate jdbcTemplate;
    private final SessionService sessionService;
    private final NotificationService notificationService;

    public OrderResponse create(OrderCreateRequest request) {
        AuthContext.LoginSession session = sessionService.requireUser();
        ListingOwnerRow listing = jdbcTemplate.query(
                        "select id, user_id as userId, type, title, status from listings where id = ?",
                        (rs, rowNum) -> {
                            ListingOwnerRow row = new ListingOwnerRow();
                            row.setId(rs.getLong("id"));
                            row.setUserId(rs.getLong("userId"));
                            row.setType(rs.getString("type"));
                            row.setTitle(rs.getString("title"));
                            row.setStatus(rs.getString("status"));
                            return row;
                        },
                        request.getListingId())
                .stream()
                .findFirst()
                .orElseThrow(() -> new BusinessException("信息不存在"));
        if (!"PUBLISHED".equals(listing.getStatus())) {
            throw new BusinessException("当前信息暂不可下单");
        }
        if (listing.getUserId().equals(session.getPrincipalId())) {
            throw new BusinessException("不能给自己发布的信息下单");
        }
        validateHandoffMethod(request.getHandoffMethod());
        String pickupCode = "SELF_PICKUP".equals(request.getHandoffMethod())
                ? UUID.randomUUID().toString().replace("-", "").substring(0, 6).toUpperCase()
                : null;
        jdbcTemplate.update(
                "insert into orders(listing_id, buyer_id, seller_id, type, status, note, trade_location, contact_phone, handoff_method, pickup_code) " +
                        "values (?, ?, ?, ?, 'PENDING_CONFIRMATION', ?, ?, ?, ?, ?)",
                request.getListingId(),
                session.getPrincipalId(),
                listing.getUserId(),
                listing.getType(),
                request.getNote(),
                request.getTradeLocation(),
                request.getContactPhone(),
                request.getHandoffMethod(),
                pickupCode
        );
        Long id = jdbcTemplate.queryForObject("select max(id) from orders", Long.class);
        notificationService.create(
                listing.getUserId(),
                "ORDER",
                "收到新的预约/交易申请",
                "你发布的《" + listing.getTitle() + "》收到了一条新的申请，请尽快确认。"
        );
        return getDetail(id);
    }

    public List<OrderResponse> myOrders() {
        AuthContext.LoginSession session = sessionService.requireUser();
        return jdbcTemplate.query(
                "select o.id, o.listing_id as listingId, l.title as listingTitle, l.type as listingType, o.buyer_id as buyerId, o.seller_id as sellerId, " +
                        "bu.nickname as buyerNickname, su.nickname as sellerNickname, o.status, o.note, o.trade_location as tradeLocation, " +
                        "o.contact_phone as contactPhone, o.handoff_method as handoffMethod, o.pickup_code as pickupCode, o.offline_paid as offlinePaid, o.created_at as createdAt, o.confirmed_at as confirmedAt, o.completed_at as completedAt " +
                        "from orders o join listings l on o.listing_id = l.id " +
                        "join users bu on o.buyer_id = bu.id join users su on o.seller_id = su.id " +
                        "where o.buyer_id = ? or o.seller_id = ? order by o.created_at desc",
                this::mapOrder,
                session.getPrincipalId(),
                session.getPrincipalId()
        );
    }

    public OrderResponse getDetail(Long id) {
        AuthContext.LoginSession session = sessionService.requireUser();
        OrderResponse response = getAnyOrder(id);
        if (!response.getBuyerId().equals(session.getPrincipalId()) && !response.getSellerId().equals(session.getPrincipalId())) {
            throw new BusinessException("你无权查看该订单");
        }
        return response;
    }

    public OrderResponse confirm(Long id) {
        AuthContext.LoginSession session = sessionService.requireUser();
        OrderResponse order = getAnyOrder(id);
        if (!order.getSellerId().equals(session.getPrincipalId())) {
            throw new BusinessException("只有发布者可以确认订单");
        }
        if (!"PENDING_CONFIRMATION".equals(order.getStatus())) {
            throw new BusinessException("当前订单状态无法确认");
        }
        jdbcTemplate.update(
                "update orders set status = 'CONFIRMED', confirmed_at = current_timestamp, updated_at = current_timestamp where id = ?",
                id
        );
        notificationService.create(
                order.getBuyerId(),
                "ORDER",
                "订单已确认",
                "你提交的《" + order.getListingTitle() + "》订单已被发布者确认。"
        );
        return getAnyOrder(id);
    }

    public OrderResponse cancel(Long id) {
        AuthContext.LoginSession session = sessionService.requireUser();
        OrderResponse order = getAnyOrder(id);
        if (!order.getBuyerId().equals(session.getPrincipalId()) && !order.getSellerId().equals(session.getPrincipalId())) {
            throw new BusinessException("你无权取消该订单");
        }
        if (!List.of("PENDING_CONFIRMATION", "CONFIRMED").contains(order.getStatus())) {
            throw new BusinessException("当前订单状态无法取消");
        }
        jdbcTemplate.update(
                "update orders set status = 'CANCELLED', updated_at = current_timestamp where id = ?",
                id
        );
        Long otherUserId = order.getBuyerId().equals(session.getPrincipalId()) ? order.getSellerId() : order.getBuyerId();
        notificationService.create(
                otherUserId,
                "ORDER",
                "订单已取消",
                "《" + order.getListingTitle() + "》订单已被取消，请查看最新状态。"
        );
        return getAnyOrder(id);
    }

    public OrderResponse complete(Long id, OrderCompleteRequest request) {
        AuthContext.LoginSession session = sessionService.requireUser();
        OrderResponse order = getAnyOrder(id);
        if (!order.getSellerId().equals(session.getPrincipalId())) {
            throw new BusinessException("只有发布者可以确认完成订单");
        }
        if (!"CONFIRMED".equals(order.getStatus())) {
            throw new BusinessException("订单未确认，不能直接完成");
        }
        jdbcTemplate.update(
                "update orders set status = 'COMPLETED', offline_paid = ?, completed_at = current_timestamp, updated_at = current_timestamp where id = ?",
                Boolean.TRUE.equals(request.getOfflinePaid()) ? 1 : 0,
                id
        );
        jdbcTemplate.update("update users set points = points + 10 where id in (?, ?)", order.getBuyerId(), order.getSellerId());
        notificationService.create(
                order.getBuyerId(),
                "ORDER",
                "订单已完成",
                "《" + order.getListingTitle() + "》已完成，系统已为你增加积分，请及时评价。"
        );
        notificationService.create(
                order.getSellerId(),
                "ORDER",
                "订单已完成",
                "《" + order.getListingTitle() + "》已完成，系统已为你增加积分，请及时评价。"
        );
        return getAnyOrder(id);
    }

    OrderResponse getAnyOrder(Long id) {
        return jdbcTemplate.query(
                        "select o.id, o.listing_id as listingId, l.title as listingTitle, l.type as listingType, o.buyer_id as buyerId, o.seller_id as sellerId, " +
                                "bu.nickname as buyerNickname, su.nickname as sellerNickname, o.status, o.note, o.trade_location as tradeLocation, " +
                                "o.contact_phone as contactPhone, o.handoff_method as handoffMethod, o.pickup_code as pickupCode, o.offline_paid as offlinePaid, o.created_at as createdAt, o.confirmed_at as confirmedAt, o.completed_at as completedAt " +
                                "from orders o join listings l on o.listing_id = l.id " +
                                "join users bu on o.buyer_id = bu.id join users su on o.seller_id = su.id where o.id = ?",
                        this::mapOrder,
                        id)
                .stream()
                .findFirst()
                .orElseThrow(() -> new BusinessException("订单不存在"));
    }

    private OrderResponse mapOrder(java.sql.ResultSet rs, int rowNum) throws java.sql.SQLException {
        OrderResponse response = new OrderResponse();
        response.setId(rs.getLong("id"));
        response.setListingId(rs.getLong("listingId"));
        response.setListingTitle(rs.getString("listingTitle"));
        response.setListingType(rs.getString("listingType"));
        response.setBuyerId(rs.getLong("buyerId"));
        response.setSellerId(rs.getLong("sellerId"));
        response.setBuyerNickname(rs.getString("buyerNickname"));
        response.setSellerNickname(rs.getString("sellerNickname"));
        response.setStatus(rs.getString("status"));
        response.setNote(rs.getString("note"));
        response.setTradeLocation(rs.getString("tradeLocation"));
        response.setContactPhone(rs.getString("contactPhone"));
        response.setHandoffMethod(rs.getString("handoffMethod"));
        response.setPickupCode(rs.getString("pickupCode"));
        response.setOfflinePaid(rs.getInt("offlinePaid") == 1);
        response.setCreatedAt(rs.getTimestamp("createdAt").toLocalDateTime());
        if (rs.getTimestamp("confirmedAt") != null) {
            response.setConfirmedAt(rs.getTimestamp("confirmedAt").toLocalDateTime());
        }
        if (rs.getTimestamp("completedAt") != null) {
            response.setCompletedAt(rs.getTimestamp("completedAt").toLocalDateTime());
        }
        return response;
    }

    private void validateHandoffMethod(String handoffMethod) {
        if (!List.of("MEETUP", "SELF_PICKUP").contains(handoffMethod)) {
            throw new BusinessException("交接方式不合法");
        }
    }

    @lombok.Data
    private static class ListingOwnerRow {
        private Long id;
        private Long userId;
        private String type;
        private String title;
        private String status;
    }
}
