package com.campus.share.domain.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AnnouncementCreateRequest {
    @NotBlank(message = "请输入公告标题")
    private String title;

    @NotBlank(message = "请输入公告内容")
    private String content;

    @NotNull(message = "请指定是否置顶")
    private Boolean pinned;
}
