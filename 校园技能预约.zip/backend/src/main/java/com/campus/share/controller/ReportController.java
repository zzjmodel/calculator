package com.campus.share.controller;

import com.campus.share.common.ApiResponse;
import com.campus.share.domain.request.ReportCreateRequest;
import com.campus.share.domain.request.ReportHandleRequest;
import com.campus.share.domain.response.ReportResponse;
import com.campus.share.service.ReportService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    @PostMapping("/api/reports")
    public ApiResponse<ReportResponse> create(@Valid @RequestBody ReportCreateRequest request) {
        return ApiResponse.ok("举报已提交", reportService.create(request));
    }

    @GetMapping("/api/admin/reports")
    public ApiResponse<List<ReportResponse>> listAll() {
        return ApiResponse.ok(reportService.listAll());
    }

    @PostMapping("/api/admin/reports/{id}/handle")
    public ApiResponse<ReportResponse> handle(@PathVariable Long id, @Valid @RequestBody ReportHandleRequest request) {
        return ApiResponse.ok("举报已处理", reportService.handle(id, request));
    }
}
