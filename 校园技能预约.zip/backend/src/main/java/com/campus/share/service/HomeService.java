package com.campus.share.service;

import com.campus.share.domain.response.HomeResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;

@Service
@RequiredArgsConstructor
public class HomeService {

    private final AnnouncementService announcementService;
    private final ListingService listingService;
    private final JdbcTemplate jdbcTemplate;

    public HomeResponse getHomeData() {
        LinkedHashMap<String, Long> stats = new LinkedHashMap<>();
        stats.put("userCount", queryCount("select count(*) from users"));
        stats.put("listingCount", queryCount("select count(*) from listings where status = 'PUBLISHED'"));
        stats.put("orderCount", queryCount("select count(*) from orders"));
        stats.put("completedOrderCount", queryCount("select count(*) from orders where status = 'COMPLETED'"));
        return new HomeResponse(announcementService.listPublished(), listingService.featured(), stats);
    }

    private long queryCount(String sql) {
        Long count = jdbcTemplate.queryForObject(sql, Long.class);
        return count == null ? 0 : count;
    }
}
