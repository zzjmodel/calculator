package com.campus.share.common;

import lombok.AllArgsConstructor;
import lombok.Data;

public final class AuthContext {

    private static final ThreadLocal<LoginSession> SESSION_HOLDER = new ThreadLocal<>();

    private AuthContext() {
    }

    public static void set(LoginSession session) {
        SESSION_HOLDER.set(session);
    }

    public static LoginSession get() {
        return SESSION_HOLDER.get();
    }

    public static void clear() {
        SESSION_HOLDER.remove();
    }

    @Data
    @AllArgsConstructor
    public static class LoginSession {
        private Long principalId;
        private String role;
        private String displayName;
        private String token;
    }
}
