package com.campus.share.domain.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ReportCreateRequest {
    @NotBlank(message = "请选择举报目标类型")
    private String targetType;

    @NotNull(message = "请选择举报目标")
    private Long targetId;

    @NotBlank(message = "请填写举报原因")
    private String reason;
}
