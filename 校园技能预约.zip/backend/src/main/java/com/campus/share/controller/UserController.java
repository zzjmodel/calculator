package com.campus.share.controller;

import com.campus.share.common.ApiResponse;
import com.campus.share.domain.request.UpdateProfileRequest;
import com.campus.share.domain.response.UserProfileResponse;
import com.campus.share.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/profile")
    public ApiResponse<UserProfileResponse> profile() {
        return ApiResponse.ok(userService.getCurrentProfile());
    }

    @PutMapping("/profile")
    public ApiResponse<UserProfileResponse> updateProfile(@RequestBody UpdateProfileRequest request) {
        return ApiResponse.ok("资料已更新", userService.updateProfile(request));
    }
}
