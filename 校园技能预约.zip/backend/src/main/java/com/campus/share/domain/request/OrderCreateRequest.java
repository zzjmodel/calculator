package com.campus.share.domain.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class OrderCreateRequest {
    @NotNull(message = "请指定信息编号")
    private Long listingId;

    private String note;

    @NotBlank(message = "请输入线下交易地点")
    private String tradeLocation;

    @NotBlank(message = "请输入联系电话")
    private String contactPhone;

    @NotBlank(message = "请选择交接方式")
    private String handoffMethod;
}
