package com.campus.share.controller;

import com.campus.share.common.ApiResponse;
import com.campus.share.domain.response.HomeResponse;
import com.campus.share.service.HomeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/home")
@RequiredArgsConstructor
public class HomeController {

    private final HomeService homeService;

    @GetMapping
    public ApiResponse<HomeResponse> home() {
        return ApiResponse.ok(homeService.getHomeData());
    }
}
