package com.campus.share.domain.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ListingCreateRequest {
    @NotBlank(message = "请选择信息类型")
    private String type;

    private Long categoryId;

    @NotBlank(message = "请输入标题")
    private String title;

    @NotBlank(message = "请输入内容描述")
    private String description;

    private String images;

    @NotNull(message = "请输入价格")
    @DecimalMin(value = "0.00", message = "价格不能小于 0")
    private BigDecimal price;

    @NotNull(message = "请输入库存")
    @Positive(message = "库存必须大于 0")
    private Integer stock;

    @NotBlank(message = "请输入交易地点")
    private String location;

    @NotBlank(message = "请输入联系方式")
    private String contact;

    private String appointmentTime;
}
