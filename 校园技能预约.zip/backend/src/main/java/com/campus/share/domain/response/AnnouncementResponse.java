package com.campus.share.domain.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AnnouncementResponse {
    private Long id;
    private String title;
    private String content;
    private Boolean pinned;
    private String status;
    private LocalDateTime publishedAt;
}
