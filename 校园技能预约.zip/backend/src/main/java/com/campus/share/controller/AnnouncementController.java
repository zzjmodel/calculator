package com.campus.share.controller;

import com.campus.share.common.ApiResponse;
import com.campus.share.domain.request.AnnouncementCreateRequest;
import com.campus.share.domain.response.AnnouncementResponse;
import com.campus.share.service.AnnouncementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class AnnouncementController {

    private final AnnouncementService announcementService;

    @GetMapping("/api/announcements")
    public ApiResponse<List<AnnouncementResponse>> listPublished() {
        return ApiResponse.ok(announcementService.listPublished());
    }

    @PostMapping("/api/admin/announcements")
    public ApiResponse<AnnouncementResponse> create(@Valid @RequestBody AnnouncementCreateRequest request) {
        return ApiResponse.ok("公告已发布", announcementService.create(request));
    }

    @PutMapping("/api/admin/announcements/{id}")
    public ApiResponse<AnnouncementResponse> update(@PathVariable Long id, @Valid @RequestBody AnnouncementCreateRequest request) {
        return ApiResponse.ok("公告已更新", announcementService.update(id, request));
    }

    @DeleteMapping("/api/admin/announcements/{id}")
    public ApiResponse<Void> delete(@PathVariable Long id) {
        announcementService.delete(id);
        return ApiResponse.ok("公告已删除", null);
    }
}
