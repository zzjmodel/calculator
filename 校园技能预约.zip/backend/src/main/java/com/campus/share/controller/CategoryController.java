package com.campus.share.controller;

import com.campus.share.common.ApiResponse;
import com.campus.share.domain.request.CategorySaveRequest;
import com.campus.share.domain.response.CategoryResponse;
import com.campus.share.service.CategoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
public class CategoryController {

    private final CategoryService categoryService;

    @GetMapping
    public ApiResponse<List<CategoryResponse>> list(@RequestParam(required = false) String type) {
        return ApiResponse.ok(categoryService.list(type));
    }

    @GetMapping("/admin")
    public ApiResponse<List<CategoryResponse>> adminList() {
        return ApiResponse.ok(categoryService.adminList());
    }

    @PostMapping("/admin")
    public ApiResponse<CategoryResponse> create(@Valid @RequestBody CategorySaveRequest request) {
        return ApiResponse.ok("分类已创建", categoryService.create(request));
    }

    @PutMapping("/admin/{id}")
    public ApiResponse<CategoryResponse> update(@PathVariable Long id, @Valid @RequestBody CategorySaveRequest request) {
        return ApiResponse.ok("分类已更新", categoryService.update(id, request));
    }

    @PostMapping("/admin/{id}/toggle-enabled")
    public ApiResponse<CategoryResponse> toggleEnabled(@PathVariable Long id) {
        return ApiResponse.ok("分类状态已更新", categoryService.toggleEnabled(id));
    }
}
