package com.campus.share.controller;

import com.campus.share.common.ApiResponse;
import com.campus.share.domain.request.AdminLoginRequest;
import com.campus.share.domain.response.AdminDashboardResponse;
import com.campus.share.domain.response.AdminUserResponse;
import com.campus.share.domain.response.AuthSessionResponse;
import com.campus.share.service.AdminService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final AdminService adminService;

    @PostMapping("/auth/login")
    public ApiResponse<AuthSessionResponse> login(@Valid @RequestBody AdminLoginRequest request) {
        return ApiResponse.ok("登录成功", adminService.login(request));
    }

    @GetMapping("/dashboard")
    public ApiResponse<AdminDashboardResponse> dashboard(@RequestParam(required = false) String type) {
        return ApiResponse.ok(adminService.dashboard(type));
    }

    @GetMapping("/users")
    public ApiResponse<List<AdminUserResponse>> users() {
        return ApiResponse.ok(adminService.users());
    }

    @PostMapping("/users/{id}/toggle-disabled")
    public ApiResponse<AdminUserResponse> toggleDisabled(@PathVariable Long id) {
        return ApiResponse.ok("用户状态已更新", adminService.toggleUserDisabled(id));
    }
}
