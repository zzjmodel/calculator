package com.campus.share.domain.request;

import lombok.Data;

@Data
public class ListingQueryRequest {
    private String keyword;
    private String type;
    private Long categoryId;
    private String status;
}
