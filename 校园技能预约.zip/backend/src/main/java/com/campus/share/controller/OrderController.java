package com.campus.share.controller;

import com.campus.share.common.ApiResponse;
import com.campus.share.domain.request.OrderCompleteRequest;
import com.campus.share.domain.request.OrderCreateRequest;
import com.campus.share.domain.response.OrderResponse;
import com.campus.share.service.OrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    @PostMapping
    public ApiResponse<OrderResponse> create(@Valid @RequestBody OrderCreateRequest request) {
        return ApiResponse.ok("下单成功", orderService.create(request));
    }

    @GetMapping
    public ApiResponse<List<OrderResponse>> myOrders() {
        return ApiResponse.ok(orderService.myOrders());
    }

    @GetMapping("/{id}")
    public ApiResponse<OrderResponse> detail(@PathVariable Long id) {
        return ApiResponse.ok(orderService.getDetail(id));
    }

    @PostMapping("/{id}/confirm")
    public ApiResponse<OrderResponse> confirm(@PathVariable Long id) {
        return ApiResponse.ok("订单已确认", orderService.confirm(id));
    }

    @PostMapping("/{id}/cancel")
    public ApiResponse<OrderResponse> cancel(@PathVariable Long id) {
        return ApiResponse.ok("订单已取消", orderService.cancel(id));
    }

    @PostMapping("/{id}/complete")
    public ApiResponse<OrderResponse> complete(@PathVariable Long id, @Valid @RequestBody OrderCompleteRequest request) {
        return ApiResponse.ok("订单已完成", orderService.complete(id, request));
    }
}
