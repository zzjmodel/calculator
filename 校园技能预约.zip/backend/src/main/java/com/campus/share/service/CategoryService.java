package com.campus.share.service;

import com.campus.share.common.BusinessException;
import com.campus.share.domain.request.CategorySaveRequest;
import com.campus.share.domain.response.CategoryResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryService {

    private final JdbcTemplate jdbcTemplate;
    private final SessionService sessionService;

    public List<CategoryResponse> list(String type) {
        if (type == null || type.isBlank()) {
            return jdbcTemplate.query(
                    "select id, name, type, enabled, sort_order as sortOrder from categories where enabled = 1 order by type, sort_order asc, id asc",
                    this::mapCategory
            );
        }
        return jdbcTemplate.query(
                "select id, name, type, enabled, sort_order as sortOrder from categories where enabled = 1 and type = ? order by sort_order asc, id asc",
                this::mapCategory,
                type
        );
    }

    public List<CategoryResponse> adminList() {
        sessionService.requireAdmin();
        return jdbcTemplate.query(
                "select id, name, type, enabled, sort_order as sortOrder from categories order by type, sort_order asc, id asc",
                this::mapCategory
        );
    }

    public CategoryResponse create(CategorySaveRequest request) {
        sessionService.requireAdmin();
        validateType(request.getType());
        jdbcTemplate.update(
                "insert into categories(name, type, sort_order, enabled) values (?, ?, ?, 1)",
                request.getName(),
                request.getType(),
                request.getSortOrder()
        );
        Long id = jdbcTemplate.queryForObject("select max(id) from categories", Long.class);
        return getById(id);
    }

    public CategoryResponse update(Long id, CategorySaveRequest request) {
        sessionService.requireAdmin();
        validateExists(id);
        validateType(request.getType());
        jdbcTemplate.update(
                "update categories set name = ?, type = ?, sort_order = ? where id = ?",
                request.getName(),
                request.getType(),
                request.getSortOrder(),
                id
        );
        return getById(id);
    }

    public CategoryResponse toggleEnabled(Long id) {
        sessionService.requireAdmin();
        CategoryResponse current = getById(id);
        jdbcTemplate.update(
                "update categories set enabled = ? where id = ?",
                Boolean.TRUE.equals(current.getEnabled()) ? 0 : 1,
                id
        );
        return getById(id);
    }

    private void validateExists(Long id) {
        Integer count = jdbcTemplate.queryForObject("select count(*) from categories where id = ?", Integer.class, id);
        if (count == null || count == 0) {
            throw new BusinessException("分类不存在");
        }
    }

    private void validateType(String type) {
        if (!List.of("SKILL", "ITEM", "HELP").contains(type)) {
            throw new BusinessException("分类类型不正确");
        }
    }

    private CategoryResponse getById(Long id) {
        return jdbcTemplate.query(
                        "select id, name, type, enabled, sort_order as sortOrder from categories where id = ?",
                        this::mapCategory,
                        id)
                .stream()
                .findFirst()
                .orElseThrow(() -> new BusinessException("分类不存在"));
    }

    private CategoryResponse mapCategory(java.sql.ResultSet rs, int rowNum) throws java.sql.SQLException {
        CategoryResponse response = new CategoryResponse();
        response.setId(rs.getLong("id"));
        response.setName(rs.getString("name"));
        response.setType(rs.getString("type"));
        response.setEnabled(rs.getInt("enabled") == 1);
        response.setSortOrder(rs.getInt("sortOrder"));
        return response;
    }
}
