package com.campus.share.service;

import com.campus.share.common.BusinessException;
import com.campus.share.domain.request.AnnouncementCreateRequest;
import com.campus.share.domain.response.AnnouncementResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AnnouncementService {

    private final JdbcTemplate jdbcTemplate;
    private final SessionService sessionService;

    public List<AnnouncementResponse> listPublished() {
        return jdbcTemplate.query(
                "select id, title, content, is_pinned as pinned, status, published_at as publishedAt from announcements " +
                        "where status = 'PUBLISHED' order by is_pinned desc, published_at desc",
                (rs, rowNum) -> {
                    AnnouncementResponse response = new AnnouncementResponse();
                    response.setId(rs.getLong("id"));
                    response.setTitle(rs.getString("title"));
                    response.setContent(rs.getString("content"));
                    response.setPinned(rs.getInt("pinned") == 1);
                    response.setStatus(rs.getString("status"));
                    response.setPublishedAt(rs.getTimestamp("publishedAt").toLocalDateTime());
                    return response;
                }
        );
    }

    public AnnouncementResponse create(AnnouncementCreateRequest request) {
        sessionService.requireAdmin();
        jdbcTemplate.update(
                "insert into announcements(title, content, is_pinned, status) values (?, ?, ?, 'PUBLISHED')",
                request.getTitle(),
                request.getContent(),
                Boolean.TRUE.equals(request.getPinned()) ? 1 : 0
        );
        return listPublished().stream().findFirst().orElseThrow(() -> new BusinessException("公告创建失败"));
    }

    public AnnouncementResponse update(Long id, AnnouncementCreateRequest request) {
        sessionService.requireAdmin();
        jdbcTemplate.update(
                "update announcements set title = ?, content = ?, is_pinned = ?, updated_at = current_timestamp where id = ?",
                request.getTitle(),
                request.getContent(),
                Boolean.TRUE.equals(request.getPinned()) ? 1 : 0,
                id
        );
        return listPublished().stream()
                .filter(item -> item.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new BusinessException("公告不存在"));
    }

    public void delete(Long id) {
        sessionService.requireAdmin();
        jdbcTemplate.update("delete from announcements where id = ?", id);
    }
}
