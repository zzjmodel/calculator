package com.campus.share.domain.request;

import lombok.Data;

@Data
public class UpdateProfileRequest {
    private String avatarUrl;
    private String nickname;
    private String department;
    private String gradeLevel;
    private String bio;
    private String tradeLocation;
}
