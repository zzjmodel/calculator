package com.campus.share.service;

import com.campus.share.common.AuthContext;
import com.campus.share.common.BusinessException;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class SessionService {

    private final Map<String, AuthContext.LoginSession> sessions = new ConcurrentHashMap<>();

    public String createUserSession(Long userId, String nickname) {
        return createSession(userId, "USER", nickname);
    }

    public String createAdminSession(Long adminId, String displayName) {
        return createSession(adminId, "ADMIN", displayName);
    }

    private String createSession(Long principalId, String role, String displayName) {
        String token = UUID.randomUUID().toString().replace("-", "");
        sessions.put(token, new AuthContext.LoginSession(principalId, role, displayName, token));
        return token;
    }

    public AuthContext.LoginSession getSession(String token) {
        return sessions.get(token);
    }

    public void remove(String token) {
        if (token != null && !token.isBlank()) {
            sessions.remove(token);
        }
    }

    public void removeUserSessions(Long principalId, String role) {
        sessions.entrySet().removeIf(entry -> role.equals(entry.getValue().getRole()) && principalId.equals(entry.getValue().getPrincipalId()));
    }

    public AuthContext.LoginSession requireLogin() {
        AuthContext.LoginSession session = AuthContext.get();
        if (session == null) {
            throw new BusinessException("请先登录后再操作");
        }
        return session;
    }

    public AuthContext.LoginSession requireUser() {
        AuthContext.LoginSession session = requireLogin();
        if (!"USER".equals(session.getRole())) {
            throw new BusinessException("当前账号无权访问用户接口");
        }
        return session;
    }

    public AuthContext.LoginSession requireAdmin() {
        AuthContext.LoginSession session = requireLogin();
        if (!"ADMIN".equals(session.getRole())) {
            throw new BusinessException("当前账号无权访问管理接口");
        }
        return session;
    }
}
