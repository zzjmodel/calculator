package com.campus.share.controller;

import com.campus.share.common.ApiResponse;
import com.campus.share.domain.request.ReviewCreateRequest;
import com.campus.share.domain.response.ReviewResponse;
import com.campus.share.service.ReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    @PostMapping("/api/reviews")
    public ApiResponse<ReviewResponse> create(@Valid @RequestBody ReviewCreateRequest request) {
        return ApiResponse.ok("评价已提交", reviewService.create(request));
    }

    @GetMapping("/api/users/{userId}/reviews")
    public ApiResponse<List<ReviewResponse>> listByUser(@PathVariable Long userId) {
        return ApiResponse.ok(reviewService.listByUser(userId));
    }
}
