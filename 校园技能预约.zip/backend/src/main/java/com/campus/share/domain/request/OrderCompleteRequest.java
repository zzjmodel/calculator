package com.campus.share.domain.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class OrderCompleteRequest {
    @NotNull(message = "请确认是否已线下支付")
    private Boolean offlinePaid;
}
