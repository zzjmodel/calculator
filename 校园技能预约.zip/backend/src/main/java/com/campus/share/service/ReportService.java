package com.campus.share.service;

import com.campus.share.common.AuthContext;
import com.campus.share.common.BusinessException;
import com.campus.share.domain.request.ReportCreateRequest;
import com.campus.share.domain.request.ReportHandleRequest;
import com.campus.share.domain.response.ReportResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final JdbcTemplate jdbcTemplate;
    private final SessionService sessionService;
    private final NotificationService notificationService;

    public ReportResponse create(ReportCreateRequest request) {
        AuthContext.LoginSession session = sessionService.requireUser();
        jdbcTemplate.update(
                "insert into reports(reporter_id, target_type, target_id, reason, status) values (?, ?, ?, ?, 'PENDING')",
                session.getPrincipalId(),
                request.getTargetType(),
                request.getTargetId(),
                request.getReason()
        );
        Long id = jdbcTemplate.queryForObject("select max(id) from reports", Long.class);
        return getById(id);
    }

    public List<ReportResponse> listAll() {
        sessionService.requireAdmin();
        return jdbcTemplate.query(
                "select r.id, r.reporter_id as reporterId, u.nickname as reporterNickname, r.target_type as targetType, r.target_id as targetId, " +
                        "r.reason, r.status, r.handle_result as handleResult, r.created_at as createdAt, r.handled_at as handledAt " +
                        "from reports r join users u on r.reporter_id = u.id order by r.created_at desc",
                this::mapReport
        );
    }

    public ReportResponse handle(Long id, ReportHandleRequest request) {
        sessionService.requireAdmin();
        Integer count = jdbcTemplate.queryForObject("select count(*) from reports where id = ?", Integer.class, id);
        if (count == null || count == 0) {
            throw new BusinessException("举报记录不存在");
        }
        jdbcTemplate.update(
                "update reports set status = 'HANDLED', handle_result = ?, handled_at = current_timestamp where id = ?",
                request.getHandleResult(),
                id
        );
        Long reporterId = jdbcTemplate.queryForObject("select reporter_id from reports where id = ?", Long.class, id);
        if (reporterId != null) {
            notificationService.create(
                    reporterId,
                    "REPORT",
                    "举报处理结果已更新",
                    "你提交的举报已被管理员处理，请前往个人中心查看处理结果。"
            );
        }
        return getById(id);
    }

    private ReportResponse getById(Long id) {
        return jdbcTemplate.query(
                        "select r.id, r.reporter_id as reporterId, u.nickname as reporterNickname, r.target_type as targetType, r.target_id as targetId, " +
                                "r.reason, r.status, r.handle_result as handleResult, r.created_at as createdAt, r.handled_at as handledAt " +
                                "from reports r join users u on r.reporter_id = u.id where r.id = ?",
                        this::mapReport,
                        id)
                .stream()
                .findFirst()
                .orElseThrow(() -> new BusinessException("举报记录不存在"));
    }

    private ReportResponse mapReport(java.sql.ResultSet rs, int rowNum) throws java.sql.SQLException {
        ReportResponse response = new ReportResponse();
        response.setId(rs.getLong("id"));
        response.setReporterId(rs.getLong("reporterId"));
        response.setReporterNickname(rs.getString("reporterNickname"));
        response.setTargetType(rs.getString("targetType"));
        response.setTargetId(rs.getLong("targetId"));
        response.setReason(rs.getString("reason"));
        response.setStatus(rs.getString("status"));
        response.setHandleResult(rs.getString("handleResult"));
        response.setCreatedAt(rs.getTimestamp("createdAt").toLocalDateTime());
        if (rs.getTimestamp("handledAt") != null) {
            response.setHandledAt(rs.getTimestamp("handledAt").toLocalDateTime());
        }
        return response;
    }
}
