package com.campus.share.controller;

import com.campus.share.common.ApiResponse;
import com.campus.share.domain.request.ListingCreateRequest;
import com.campus.share.domain.request.ListingQueryRequest;
import com.campus.share.domain.response.ListingResponse;
import com.campus.share.service.ListingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/listings")
@RequiredArgsConstructor
public class ListingController {

    private final ListingService listingService;

    @GetMapping
    public ApiResponse<List<ListingResponse>> list(ListingQueryRequest request) {
        return ApiResponse.ok(listingService.list(request));
    }

    @GetMapping("/{id}")
    public ApiResponse<ListingResponse> detail(@PathVariable Long id) {
        return ApiResponse.ok(listingService.getDetail(id));
    }

    @GetMapping("/mine")
    public ApiResponse<List<ListingResponse>> mine() {
        return ApiResponse.ok(listingService.myListings());
    }

    @PostMapping
    public ApiResponse<ListingResponse> create(@Valid @RequestBody ListingCreateRequest request) {
        return ApiResponse.ok("发布成功", listingService.create(request));
    }

    @PutMapping("/{id}")
    public ApiResponse<ListingResponse> update(@PathVariable Long id, @Valid @RequestBody ListingCreateRequest request) {
        return ApiResponse.ok("更新成功", listingService.update(id, request));
    }

    @PostMapping("/{id}/status")
    public ApiResponse<ListingResponse> changeStatus(@PathVariable Long id, @RequestParam String status) {
        return ApiResponse.ok("状态已更新", listingService.changeStatus(id, status));
    }

    @GetMapping("/admin/all")
    public ApiResponse<List<ListingResponse>> adminList(@RequestParam(required = false) String status) {
        return ApiResponse.ok(listingService.adminList(status));
    }

    @PostMapping("/admin/{id}/status")
    public ApiResponse<ListingResponse> adminChangeStatus(@PathVariable Long id, @RequestParam String status) {
        return ApiResponse.ok("信息状态已更新", listingService.adminChangeStatus(id, status));
    }
}
