package com.campus.share.service;

import com.campus.share.common.AuthContext;
import com.campus.share.common.BusinessException;
import com.campus.share.domain.request.ReviewCreateRequest;
import com.campus.share.domain.response.ReviewResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewService {

    private final JdbcTemplate jdbcTemplate;
    private final SessionService sessionService;
    private final OrderService orderService;
    private final NotificationService notificationService;

    public ReviewResponse create(ReviewCreateRequest request) {
        AuthContext.LoginSession session = sessionService.requireUser();
        var order = orderService.getAnyOrder(request.getOrderId());
        if (!"COMPLETED".equals(order.getStatus())) {
            throw new BusinessException("订单完成后才可以评价");
        }
        if (!order.getBuyerId().equals(session.getPrincipalId()) && !order.getSellerId().equals(session.getPrincipalId())) {
            throw new BusinessException("你无权评价该订单");
        }
        Integer count = jdbcTemplate.queryForObject(
                "select count(*) from reviews where order_id = ? and reviewer_id = ?",
                Integer.class,
                request.getOrderId(),
                session.getPrincipalId()
        );
        if (count != null && count > 0) {
            throw new BusinessException("你已经评价过该订单");
        }
        Long revieweeId = order.getBuyerId().equals(session.getPrincipalId()) ? order.getSellerId() : order.getBuyerId();
        jdbcTemplate.update(
                "insert into reviews(order_id, reviewer_id, reviewee_id, rating, content) values (?, ?, ?, ?, ?)",
                request.getOrderId(),
                session.getPrincipalId(),
                revieweeId,
                request.getRating(),
                request.getContent()
        );
        notificationService.create(
                revieweeId,
                "REVIEW",
                "收到新的评价",
                "你收到了一条新的订单评价，快去个人中心查看吧。"
        );
        return listByUser(revieweeId).stream().findFirst().orElseThrow(() -> new BusinessException("评价保存失败"));
    }

    public List<ReviewResponse> listByUser(Long userId) {
        return jdbcTemplate.query(
                "select r.id, r.order_id as orderId, r.reviewer_id as reviewerId, r.reviewee_id as revieweeId, u.nickname as reviewerNickname, r.rating, r.content, r.created_at as createdAt " +
                        "from reviews r join users u on r.reviewer_id = u.id where r.reviewee_id = ? order by r.created_at desc",
                (rs, rowNum) -> {
                    ReviewResponse response = new ReviewResponse();
                    response.setId(rs.getLong("id"));
                    response.setOrderId(rs.getLong("orderId"));
                    response.setReviewerId(rs.getLong("reviewerId"));
                    response.setRevieweeId(rs.getLong("revieweeId"));
                    response.setReviewerNickname(rs.getString("reviewerNickname"));
                    response.setRating(rs.getInt("rating"));
                    response.setContent(rs.getString("content"));
                    response.setCreatedAt(rs.getTimestamp("createdAt").toLocalDateTime());
                    return response;
                },
                userId
        );
    }
}
