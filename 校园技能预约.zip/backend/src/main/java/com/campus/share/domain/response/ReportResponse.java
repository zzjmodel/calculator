package com.campus.share.domain.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ReportResponse {
    private Long id;
    private Long reporterId;
    private String reporterNickname;
    private String targetType;
    private Long targetId;
    private String reason;
    private String status;
    private String handleResult;
    private LocalDateTime createdAt;
    private LocalDateTime handledAt;
}
