package com.campus.share.controller;

import com.campus.share.common.ApiResponse;
import com.campus.share.domain.response.NotificationResponse;
import com.campus.share.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    @GetMapping
    public ApiResponse<List<NotificationResponse>> myNotifications() {
        return ApiResponse.ok(notificationService.myNotifications());
    }

    @PostMapping("/read-all")
    public ApiResponse<Void> readAll() {
        notificationService.markAllRead();
        return ApiResponse.ok("消息已全部标记为已读", null);
    }
}
