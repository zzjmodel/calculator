package com.campus.share.service;

import com.campus.share.common.PasswordCodec;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BootstrapService {

    private final JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void initialize() {
        seedAdmin();
        seedCategories();
        seedAnnouncements();
        seedDemoUsers();
        seedDemoListings();
        seedDemoOrders();
        seedDemoReviews();
        seedDemoNotifications();
    }

    private void seedAdmin() {
        Integer count = jdbcTemplate.queryForObject("select count(*) from admin_users", Integer.class);
        if (count != null && count > 0) {
            return;
        }
        jdbcTemplate.update(
                "insert into admin_users(username, password_hash, display_name) values (?, ?, ?)",
                "admin",
                PasswordCodec.encode("123456"),
                "系统管理员"
        );
    }

    private void seedCategories() {
        Integer count = jdbcTemplate.queryForObject("select count(*) from categories", Integer.class);
        if (count != null && count > 0) {
            return;
        }
        List<Object[]> seeds = List.of(
                new Object[]{"程序辅导", "SKILL", 1},
                new Object[]{"设计剪辑", "SKILL", 2},
                new Object[]{"学习陪练", "SKILL", 3},
                new Object[]{"电子设备", "ITEM", 1},
                new Object[]{"教材资料", "ITEM", 2},
                new Object[]{"生活用品", "ITEM", 3},
                new Object[]{"跑腿代办", "HELP", 1},
                new Object[]{"组队互助", "HELP", 2}
        );
        for (Object[] seed : seeds) {
            jdbcTemplate.update(
                    "insert into categories(name, type, sort_order, enabled) values (?, ?, ?, 1)",
                    seed[0], seed[1], seed[2]
            );
        }
    }

    private void seedAnnouncements() {
        Integer count = jdbcTemplate.queryForObject("select count(*) from announcements", Integer.class);
        if (count != null && count > 0) {
            return;
        }
        jdbcTemplate.update(
                "insert into announcements(title, content, is_pinned, status) values (?, ?, 1, 'PUBLISHED')",
                "欢迎使用校园共享平台",
                "当前版本聚焦技能预约、闲置交易与求助互助，支付方式统一登记为线下支付。"
        );
    }

    private void seedDemoUsers() {
        ensureDemoUser("20221001", "13800000011", "小林同学", "计算机学院", "2022级", "擅长程序辅导和前端页面优化", "一教门口");
        ensureDemoUser("20221002", "13800000012", "阿周同学", "数学学院", "2022级", "长期整理教材和电子设备闲置", "图书馆一楼");
        ensureDemoUser("20221003", "13800000013", "晴晴同学", "外国语学院", "2023级", "经常发布跑腿和组队互助信息", "宿舍楼下");
    }

    private void seedDemoListings() {
        Integer count = jdbcTemplate.queryForObject("select count(*) from listings", Integer.class);
        if (count != null && count > 0) {
            return;
        }
        Long userOneId = findUserIdByStudentId("20221001");
        Long userTwoId = findUserIdByStudentId("20221002");
        Long userThreeId = findUserIdByStudentId("20221003");
        Long skillCategoryId = findCategoryId("程序辅导");
        Long itemCategoryId = findCategoryId("电子设备");
        Long helpCategoryId = findCategoryId("跑腿代办");

        jdbcTemplate.update(
                "insert into listings(user_id, type, category_id, title, description, images, price, stock, location, contact, appointment_time, status, view_count) " +
                        "values (?, 'SKILL', ?, ?, ?, ?, 35.00, 1, ?, ?, ?, 'PUBLISHED', 16)",
                userOneId,
                skillCategoryId,
                "SpringBoot 接口辅导",
                "可辅导课程设计、接口联调、数据库表设计，适合软件工程同学结课冲刺。",
                "",
                "第一教学楼 203",
                "13800000011",
                "周三晚 19:00 - 21:00"
        );
        jdbcTemplate.update(
                "insert into listings(user_id, type, category_id, title, description, images, price, stock, location, contact, appointment_time, status, view_count) " +
                        "values (?, 'ITEM', ?, ?, ?, ?, 299.00, 1, ?, ?, ?, 'PUBLISHED', 23)",
                userTwoId,
                itemCategoryId,
                "九成新机械键盘转让",
                "宿舍闲置机械键盘，青轴，带灯效，适合写代码和日常办公。",
                "",
                "图书馆南门",
                "13800000012",
                "工作日中午可当面交易"
        );
        jdbcTemplate.update(
                "insert into listings(user_id, type, category_id, title, description, images, price, stock, location, contact, appointment_time, status, view_count) " +
                        "values (?, 'HELP', ?, ?, ?, ?, 8.00, 3, ?, ?, ?, 'PUBLISHED', 11)",
                userThreeId,
                helpCategoryId,
                "代取快递与打印资料",
                "可帮忙代取菜鸟驿站快递，也可以顺路打印课程资料，当天响应。",
                "",
                "三食堂附近",
                "13800000013",
                "每天 12:00 前、18:00 后"
        );
    }

    private void seedDemoOrders() {
        Integer count = jdbcTemplate.queryForObject("select count(*) from orders", Integer.class);
        if (count != null && count > 0) {
            return;
        }
        Long buyerId = findUserIdByStudentId("20221002");
        Long sellerId = findUserIdByStudentId("20221001");
        Long listingId = jdbcTemplate.queryForObject(
                "select id from listings where title = ?",
                Long.class,
                "SpringBoot 接口辅导"
        );
        if (listingId == null) {
            return;
        }
        jdbcTemplate.update(
                "insert into orders(listing_id, buyer_id, seller_id, type, status, note, trade_location, contact_phone, handoff_method, pickup_code, offline_paid, confirmed_at, completed_at) " +
                        "values (?, ?, ?, 'SKILL', 'COMPLETED', ?, ?, ?, 'SELF_PICKUP', 'A1B2C3', 1, current_timestamp, current_timestamp)",
                listingId,
                buyerId,
                sellerId,
                "希望重点讲接口联调与异常处理",
                "第一教学楼 203",
                "13800000012"
        );
        jdbcTemplate.update("update users set points = points + 10 where id in (?, ?)", buyerId, sellerId);
    }

    private void seedDemoReviews() {
        Integer count = jdbcTemplate.queryForObject("select count(*) from reviews", Integer.class);
        if (count != null && count > 0) {
            return;
        }
        Long orderId = jdbcTemplate.queryForObject("select id from orders order by id asc limit 1", Long.class);
        Long reviewerId = findUserIdByStudentId("20221002");
        Long revieweeId = findUserIdByStudentId("20221001");
        if (orderId == null || reviewerId == null || revieweeId == null) {
            return;
        }
        jdbcTemplate.update(
                "insert into reviews(order_id, reviewer_id, reviewee_id, rating, content) values (?, ?, ?, ?, ?)",
                orderId,
                reviewerId,
                revieweeId,
                5,
                "讲解细致，能直接帮我把接口和前端联调思路理顺。"
        );
    }

    private void seedDemoNotifications() {
        Integer count = jdbcTemplate.queryForObject("select count(*) from notifications", Integer.class);
        if (count != null && count > 0) {
            return;
        }
        Long userOneId = findUserIdByStudentId("20221001");
        Long userTwoId = findUserIdByStudentId("20221002");
        if (userOneId != null) {
            jdbcTemplate.update(
                    "insert into notifications(user_id, type, title, content, is_read) values (?, 'ORDER', ?, ?, 0)",
                    userOneId,
                    "演示提醒：订单已完成",
                    "你有一笔演示订单已经完成，系统已自动发放积分。"
            );
        }
        if (userTwoId != null) {
            jdbcTemplate.update(
                    "insert into notifications(user_id, type, title, content, is_read) values (?, 'REVIEW', ?, ?, 0)",
                    userTwoId,
                    "演示提醒：请补充评价",
                    "你参与的演示订单已完成，可以前往详情页提交评价。"
            );
        }
    }

    private void ensureDemoUser(String studentId, String phone, String nickname, String department, String gradeLevel, String bio, String tradeLocation) {
        Integer count = jdbcTemplate.queryForObject("select count(*) from users where student_id = ?", Integer.class, studentId);
        if (count != null && count > 0) {
            return;
        }
        jdbcTemplate.update(
                "insert into users(student_id, phone, password_hash, nickname, department, grade_level, bio, trade_location, certification_status) " +
                        "values (?, ?, ?, ?, ?, ?, ?, ?, 'APPROVED')",
                studentId,
                phone,
                PasswordCodec.encode("123456"),
                nickname,
                department,
                gradeLevel,
                bio,
                tradeLocation
        );
    }

    private Long findUserIdByStudentId(String studentId) {
        return jdbcTemplate.queryForObject("select id from users where student_id = ?", Long.class, studentId);
    }

    private Long findCategoryId(String name) {
        return jdbcTemplate.queryForObject("select id from categories where name = ?", Long.class, name);
    }
}
