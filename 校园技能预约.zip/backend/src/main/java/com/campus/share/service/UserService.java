package com.campus.share.service;

import com.campus.share.common.AuthContext;
import com.campus.share.common.BusinessException;
import com.campus.share.domain.request.UpdateProfileRequest;
import com.campus.share.domain.response.UserProfileResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {

    private final JdbcTemplate jdbcTemplate;
    private final SessionService sessionService;

    public UserProfileResponse getCurrentProfile() {
        AuthContext.LoginSession session = sessionService.requireUser();
        return getUserProfile(session.getPrincipalId());
    }

    public UserProfileResponse updateProfile(UpdateProfileRequest request) {
        AuthContext.LoginSession session = sessionService.requireUser();
        UserProfileResponse current = getUserProfile(session.getPrincipalId());
        jdbcTemplate.update(
                "update users set avatar_url = ?, nickname = ?, department = ?, grade_level = ?, bio = ?, trade_location = ?, updated_at = current_timestamp where id = ?",
                emptyToNull(request.getAvatarUrl()),
                keepNickname(request.getNickname(), current.getNickname()),
                emptyToNull(request.getDepartment()),
                emptyToNull(request.getGradeLevel()),
                emptyToNull(request.getBio()),
                emptyToNull(request.getTradeLocation()),
                session.getPrincipalId()
        );
        return getUserProfile(session.getPrincipalId());
    }

    public UserProfileResponse getUserProfile(Long userId) {
        List<UserProfileResponse> list = jdbcTemplate.query(
                "select id, student_id as studentId, phone, nickname, avatar_url as avatarUrl, department, grade_level as gradeLevel, " +
                        "bio, trade_location as tradeLocation, points, is_disabled as disabled, certification_status as certificationStatus " +
                        "from users where id = ?",
                (rs, rowNum) -> {
                    UserProfileResponse response = new UserProfileResponse();
                    response.setId(rs.getLong("id"));
                    response.setStudentId(rs.getString("studentId"));
                    response.setPhone(rs.getString("phone"));
                    response.setNickname(rs.getString("nickname"));
                    response.setAvatarUrl(rs.getString("avatarUrl"));
                    response.setDepartment(rs.getString("department"));
                    response.setGradeLevel(rs.getString("gradeLevel"));
                    response.setBio(rs.getString("bio"));
                    response.setTradeLocation(rs.getString("tradeLocation"));
                    response.setPoints(rs.getInt("points"));
                    response.setDisabled(rs.getInt("disabled") == 1);
                    response.setCertificationStatus(rs.getString("certificationStatus"));
                    return response;
                },
                userId
        );
        if (list.isEmpty()) {
            throw new BusinessException("用户不存在");
        }
        UserProfileResponse response = list.getFirst();
        Integer completedCount = jdbcTemplate.queryForObject(
                "select count(*) from orders where status = 'COMPLETED' and (buyer_id = ? or seller_id = ?)",
                Integer.class,
                userId,
                userId
        );
        BigDecimal average = jdbcTemplate.queryForObject(
                "select avg(rating) from reviews where reviewee_id = ?",
                BigDecimal.class,
                userId
        );
        response.setCompletedOrderCount(completedCount == null ? 0 : completedCount);
        response.setAverageRating(average == null ? 0D : average.setScale(1, RoundingMode.HALF_UP).doubleValue());
        return response;
    }

    private String keepNickname(String nickname, String currentNickname) {
        if (nickname == null || nickname.isBlank()) {
            return currentNickname;
        }
        return nickname.trim();
    }

    private String emptyToNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return value;
    }
}
