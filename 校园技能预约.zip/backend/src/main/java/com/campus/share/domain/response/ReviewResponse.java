package com.campus.share.domain.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ReviewResponse {
    private Long id;
    private Long orderId;
    private Long reviewerId;
    private Long revieweeId;
    private String reviewerNickname;
    private Integer rating;
    private String content;
    private LocalDateTime createdAt;
}
