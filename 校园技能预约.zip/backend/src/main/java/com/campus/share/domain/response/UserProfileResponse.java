package com.campus.share.domain.response;

import lombok.Data;

@Data
public class UserProfileResponse {
    private Long id;
    private String studentId;
    private String phone;
    private String nickname;
    private String avatarUrl;
    private String department;
    private String gradeLevel;
    private String bio;
    private String tradeLocation;
    private Integer points;
    private Boolean disabled;
    private String certificationStatus;
    private Double averageRating;
    private Integer completedOrderCount;
}
