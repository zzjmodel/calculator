package com.campus.share.service;

import com.campus.share.common.BusinessException;
import com.campus.share.common.PasswordCodec;
import com.campus.share.domain.request.AdminLoginRequest;
import com.campus.share.domain.response.AdminUserResponse;
import com.campus.share.domain.response.AdminDashboardResponse;
import com.campus.share.domain.response.AuthSessionResponse;
import com.campus.share.domain.response.StatsItemResponse;
import com.campus.share.domain.response.StatsTrendPointResponse;
import com.campus.share.domain.response.UserProfileResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final JdbcTemplate jdbcTemplate;
    private final SessionService sessionService;

    public AuthSessionResponse login(AdminLoginRequest request) {
        List<AdminRow> rows = jdbcTemplate.query(
                "select id, username, password_hash as passwordHash, display_name as displayName from admin_users where username = ?",
                (rs, rowNum) -> {
                    AdminRow row = new AdminRow();
                    row.setId(rs.getLong("id"));
                    row.setUsername(rs.getString("username"));
                    row.setPasswordHash(rs.getString("passwordHash"));
                    row.setDisplayName(rs.getString("displayName"));
                    return row;
                },
                request.getUsername()
        );
        if (rows.isEmpty()) {
            throw new BusinessException("管理员账号或密码错误");
        }
        AdminRow admin = rows.getFirst();
        if (!PasswordCodec.matches(request.getPassword(), admin.getPasswordHash())) {
            throw new BusinessException("管理员账号或密码错误");
        }
        String token = sessionService.createAdminSession(admin.getId(), admin.getDisplayName());
        UserProfileResponse placeholder = new UserProfileResponse();
        placeholder.setId(admin.getId());
        placeholder.setNickname(admin.getDisplayName());
        placeholder.setCertificationStatus("ADMIN");
        return new AuthSessionResponse(token, "ADMIN", placeholder);
    }

    public AdminDashboardResponse dashboard(String type) {
        sessionService.requireAdmin();
        String normalizedType = normalizeType(type);
        AdminDashboardResponse response = new AdminDashboardResponse();
        response.setUserCount(queryCount("select count(*) from users"));
        response.setListingCount(queryCount(
                "select count(*) from listings" + typeWhereClause("type", normalizedType)
        ));
        response.setOrderCount(queryCount(
                "select count(*) from orders" + typeWhereClause("type", normalizedType)
        ));
        response.setCompletedOrderCount(queryCount("select count(*) from orders where status = 'COMPLETED'"));
        response.setPendingCertificationCount(queryCount("select count(*) from certification_requests where status = 'SUBMITTED'"));
        response.setPendingReportCount(queryCount("select count(*) from reports where status = 'PENDING'"));
        response.setListingTypeStats(queryStats(
                "select type as itemKey, count(*) as total from listings" +
                        typeWhereClause("type", normalizedType) +
                        " group by type order by total desc",
                "itemKey",
                "total"
        ));
        response.setOrderStatusStats(queryStats(
                "select status as itemKey, count(*) as total from orders" +
                        typeWhereClause("type", normalizedType) +
                        " group by status order by total desc",
                "itemKey",
                "total"
        ));
        response.setHotCategoryStats(queryStats(
                "select coalesce(c.name, '未分类') as itemKey, count(*) as total " +
                        "from listings l left join categories c on l.category_id = c.id " +
                        (" where ?".equals(typeWhereClause("l.type", normalizedType)) ? "where l.type = '" + normalizedType + "' " : "") +
                        "group by coalesce(c.name, '未分类') order by total desc limit 5",
                "itemKey",
                "total"
        ));
        response.setRecentListingTrend(queryDailyTrend("listings", "created_at", normalizedType));
        response.setRecentOrderTrend(queryDailyTrend("orders", "created_at", normalizedType));
        return response;
    }

    public List<AdminUserResponse> users() {
        sessionService.requireAdmin();
        return jdbcTemplate.query(
                "select id, student_id as studentId, phone, nickname, department, grade_level as gradeLevel, is_disabled as disabled, " +
                        "certification_status as certificationStatus, created_at as createdAt from users order by created_at desc",
                (rs, rowNum) -> {
                    AdminUserResponse response = new AdminUserResponse();
                    response.setId(rs.getLong("id"));
                    response.setStudentId(rs.getString("studentId"));
                    response.setPhone(rs.getString("phone"));
                    response.setNickname(rs.getString("nickname"));
                    response.setDepartment(rs.getString("department"));
                    response.setGradeLevel(rs.getString("gradeLevel"));
                    response.setDisabled(rs.getInt("disabled") == 1);
                    response.setCertificationStatus(rs.getString("certificationStatus"));
                    response.setCreatedAt(rs.getTimestamp("createdAt").toLocalDateTime());
                    return response;
                }
        );
    }

    public AdminUserResponse toggleUserDisabled(Long userId) {
        sessionService.requireAdmin();
        List<Boolean> disabledValues = jdbcTemplate.query(
                "select is_disabled as disabled from users where id = ?",
                (rs, rowNum) -> rs.getInt("disabled") == 1,
                userId
        );
        if (disabledValues.isEmpty()) {
            throw new BusinessException("用户不存在");
        }
        boolean nextDisabled = !disabledValues.getFirst();
        jdbcTemplate.update(
                "update users set is_disabled = ?, updated_at = current_timestamp where id = ?",
                nextDisabled ? 1 : 0,
                userId
        );
        if (nextDisabled) {
            sessionService.removeUserSessions(userId, "USER");
        }
        return users().stream()
                .filter(item -> item.getId().equals(userId))
                .findFirst()
                .orElseThrow(() -> new BusinessException("用户不存在"));
    }

    private long queryCount(String sql) {
        Long count = jdbcTemplate.queryForObject(sql, Long.class);
        return count == null ? 0 : count;
    }

    private List<StatsItemResponse> queryStats(String sql, String keyColumn, String totalColumn) {
        return jdbcTemplate.query(
                sql,
                (rs, rowNum) -> new StatsItemResponse(
                        rs.getString(keyColumn),
                        rs.getString(keyColumn),
                        rs.getLong(totalColumn)
                )
        );
    }

    private List<StatsTrendPointResponse> queryDailyTrend(String tableName, String timeColumn, String type) {
        LocalDate startDate = LocalDate.now().minusDays(6);
        Map<LocalDate, Long> trendMap = new LinkedHashMap<>();
        for (int i = 0; i < 7; i++) {
            LocalDate date = startDate.plusDays(i);
            trendMap.put(date, 0L);
        }

        jdbcTemplate.query(
                "select cast(" + timeColumn + " as date) as statDate, count(*) as total " +
                        "from " + tableName + " " +
                        "where " + timeColumn + " >= dateadd('DAY', -6, current_timestamp) " +
                        (type == null ? "" : "and type = '" + type + "' ") +
                        "group by cast(" + timeColumn + " as date) order by statDate",
                rs -> {
                    LocalDate date = rs.getDate("statDate").toLocalDate();
                    if (trendMap.containsKey(date)) {
                        trendMap.put(date, rs.getLong("total"));
                    }
                }
        );

        List<StatsTrendPointResponse> result = new ArrayList<>();
        for (Map.Entry<LocalDate, Long> entry : trendMap.entrySet()) {
            result.add(new StatsTrendPointResponse(entry.getKey().toString(), entry.getValue()));
        }
        return result;
    }

    private String normalizeType(String type) {
        if (type == null || type.isBlank()) {
            return null;
        }
        return switch (type) {
            case "SKILL", "ITEM", "HELP" -> type;
            default -> throw new BusinessException("统计类型不正确");
        };
    }

    private String typeWhereClause(String column, String type) {
        return type == null ? "" : " where " + column + " = '" + type + "'";
    }

    @lombok.Data
    private static class AdminRow {
        private Long id;
        private String username;
        private String passwordHash;
        private String displayName;
    }
}
