package com.campus.share.domain.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AuthSessionResponse {
    private String token;
    private String role;
    private UserProfileResponse user;
}
