package com.campus.share.domain.response;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ListingResponse {
    private Long id;
    private String type;
    private Long categoryId;
    private String categoryName;
    private Long userId;
    private String userNickname;
    private String title;
    private String description;
    private String images;
    private BigDecimal price;
    private Integer stock;
    private String location;
    private String contact;
    private String appointmentTime;
    private String status;
    private Integer viewCount;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
