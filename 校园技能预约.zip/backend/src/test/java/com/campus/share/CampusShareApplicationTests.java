package com.campus.share;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusShareApplicationTests {

    @Test
    void contextLoads() {
    }
}
