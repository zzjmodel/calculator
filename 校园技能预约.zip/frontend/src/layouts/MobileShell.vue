<script setup lang="ts">
import { computed } from 'vue'
import { RouterLink, RouterView, useRoute } from 'vue-router'
import { ClipboardList, Compass, House, SquarePen, UserRound } from 'lucide-vue-next'

const route = useRoute()

const navItems = [
  { label: '首页', to: '/app/home', icon: House },
  { label: '发现', to: '/app/explore', icon: Compass },
  { label: '发布', to: '/app/publish', icon: SquarePen },
  { label: '订单', to: '/app/orders', icon: ClipboardList },
  { label: '我的', to: '/app/profile', icon: UserRound },
]

const title = computed(() => (route.meta.title as string | undefined) ?? '校园共享')
</script>

<template>
  <div class="mobile-page flex flex-col">
    <header class="sticky top-0 z-10 border-b px-5 py-4 backdrop-blur-xl" style="border-color: var(--line); background: rgba(255, 250, 240, 0.94);">
      <p class="text-xs uppercase tracking-[0.28em] muted">Campus Share</p>
      <div class="mt-2 flex items-center justify-between">
        <h1 class="text-xl font-semibold">{{ title }}</h1>
        <RouterLink to="/admin/login" class="rounded-full px-3 py-1 text-xs font-medium" style="background: var(--primary-soft); color: var(--primary);">
          管理入口
        </RouterLink>
      </div>
    </header>

    <main class="flex-1 px-4 py-4">
      <RouterView />
    </main>

    <nav class="sticky bottom-0 grid grid-cols-5 border-t px-2 py-2 backdrop-blur-xl" style="border-color: var(--line); background: rgba(255, 250, 241, 0.96);">
      <RouterLink
        v-for="item in navItems"
        :key="item.to"
        :to="item.to"
        class="flex flex-col items-center justify-center gap-1 rounded-2xl py-2 text-[11px] font-medium"
        :class="route.path.startsWith(item.to) ? 'text-white' : 'muted'"
        :style="route.path.startsWith(item.to) ? 'background: linear-gradient(135deg, #c55b33 0%, #d2813e 100%);' : ''"
      >
        <component :is="item.icon" class="h-4 w-4" />
        <span>{{ item.label }}</span>
      </RouterLink>
    </nav>
  </div>
</template>
