export const listingTypeLabels: Record<string, string> = {
  SKILL: '技能服务',
  ITEM: '闲置物品',
  HELP: '求助互助',
}

export const orderStatusLabels: Record<string, string> = {
  PENDING_CONFIRMATION: '待确认',
  CONFIRMED: '已确认',
  CANCELLED: '已取消',
  COMPLETED: '已完成',
  CLOSED: '已关闭',
}

export const certificationStatusLabels: Record<string, string> = {
  NONE: '未认证',
  SUBMITTED: '待审核',
  APPROVED: '已通过',
  REJECTED: '已驳回',
  ADMIN: '管理员',
}

export const reportStatusLabels: Record<string, string> = {
  PENDING: '待处理',
  HANDLED: '已处理',
}

export const listingStatusLabels: Record<string, string> = {
  PUBLISHED: '上架中',
  OFFLINE: '已下架',
}

export const handoffMethodLabels: Record<string, string> = {
  MEETUP: '线下约见',
  SELF_PICKUP: '校内自提',
}

export const defaultTypeTabs = [
  { label: '全部', value: '' },
  { label: '技能服务', value: 'SKILL' },
  { label: '闲置物品', value: 'ITEM' },
  { label: '求助互助', value: 'HELP' },
]
