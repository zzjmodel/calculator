<script setup lang="ts">
import { RouterLink } from 'vue-router'
import { MapPin, UserRound } from 'lucide-vue-next'
import { listingTypeLabels } from '../constants/labels'
import { formatPrice, formatTime, toLabel } from '../utils/format'
import type { Listing } from '../types'

defineProps<{
  item: Listing
}>()
</script>

<template>
  <RouterLink :to="`/app/listing/${item.id}`" class="card block rounded-[24px] p-4">
    <div class="flex items-start justify-between gap-3">
      <div>
        <p class="text-xs font-medium" style="color: var(--primary)">{{ toLabel(item.type, listingTypeLabels) }}</p>
        <h3 class="mt-1 text-sm font-semibold leading-6">{{ item.title }}</h3>
      </div>
      <span class="rounded-full px-3 py-1 text-xs font-semibold" style="background: var(--primary-soft); color: var(--primary)">
        {{ formatPrice(item.price) }}
      </span>
    </div>
    <p class="mt-3 line-clamp-2 text-sm muted">{{ item.description }}</p>
    <div class="mt-4 flex flex-wrap items-center gap-3 text-xs muted">
      <span class="inline-flex items-center gap-1">
        <MapPin class="h-3.5 w-3.5" />
        {{ item.location }}
      </span>
      <span class="inline-flex items-center gap-1">
        <UserRound class="h-3.5 w-3.5" />
        {{ item.userNickname }}
      </span>
      <span>{{ formatTime(item.createdAt) }}</span>
    </div>
  </RouterLink>
</template>
