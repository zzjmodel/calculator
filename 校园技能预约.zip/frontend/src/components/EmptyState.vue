<script setup lang="ts">
import { Inbox } from 'lucide-vue-next'

withDefaults(
  defineProps<{
    title?: string
    description: string
  }>(),
  {
    title: '暂无内容',
  },
)
</script>

<template>
  <div class="card rounded-[24px] px-5 py-8 text-center">
    <div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full" style="background: #fff1e3; color: var(--primary)">
      <Inbox class="h-5 w-5" />
    </div>
    <p class="mt-4 text-sm font-semibold">{{ title }}</p>
    <p class="mt-2 text-sm leading-6 muted">{{ description }}</p>
  </div>
</template>
