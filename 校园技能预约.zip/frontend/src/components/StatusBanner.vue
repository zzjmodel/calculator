<script setup lang="ts">
const props = withDefaults(
  defineProps<{
    type?: 'success' | 'error' | 'info'
    text: string
  }>(),
  {
    type: 'info',
  },
)

const paletteMap = {
  success: {
    background: 'rgba(37, 111, 75, 0.1)',
    border: 'rgba(37, 111, 75, 0.2)',
    color: 'var(--success)',
  },
  error: {
    background: 'rgba(181, 65, 51, 0.08)',
    border: 'rgba(181, 65, 51, 0.2)',
    color: 'var(--danger)',
  },
  info: {
    background: 'rgba(197, 91, 51, 0.08)',
    border: 'rgba(197, 91, 51, 0.18)',
    color: 'var(--primary)',
  },
}

const palette = paletteMap[props.type]
</script>

<template>
  <div
    class="rounded-2xl border px-4 py-3 text-sm"
    :style="{
      background: palette.background,
      borderColor: palette.border,
      color: palette.color,
    }"
  >
    {{ text }}
  </div>
</template>
