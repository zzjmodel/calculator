import { defineStore } from 'pinia'
import { api } from '../api/services'
import type { AuthSession, UserProfile } from '../types'

interface AuthState {
  token: string
  role: '' | 'USER' | 'ADMIN'
  user: UserProfile | null
}

const TOKEN_KEY = 'campus-share-token'
const ROLE_KEY = 'campus-share-role'
const USER_KEY = 'campus-share-user'

export const useAuthStore = defineStore('auth', {
  state: (): AuthState => ({
    token: localStorage.getItem(TOKEN_KEY) ?? '',
    role: (localStorage.getItem(ROLE_KEY) as AuthState['role']) ?? '',
    user: localStorage.getItem(USER_KEY) ? JSON.parse(localStorage.getItem(USER_KEY) as string) : null,
  }),
  getters: {
    isAuthenticated: (state) => Boolean(state.token),
    isUser: (state) => state.role === 'USER',
    isAdmin: (state) => state.role === 'ADMIN',
  },
  actions: {
    setSession(session: AuthSession) {
      this.token = session.token
      this.role = session.role
      this.user = session.user
      localStorage.setItem(TOKEN_KEY, session.token)
      localStorage.setItem(ROLE_KEY, session.role)
      localStorage.setItem(USER_KEY, JSON.stringify(session.user))
    },
    setUser(user: UserProfile) {
      this.user = user
      localStorage.setItem(USER_KEY, JSON.stringify(user))
    },
    clear() {
      this.token = ''
      this.role = ''
      this.user = null
      localStorage.removeItem(TOKEN_KEY)
      localStorage.removeItem(ROLE_KEY)
      localStorage.removeItem(USER_KEY)
    },
    async refreshMe() {
      if (!this.token || this.role !== 'USER') {
        return
      }
      const user = await api.me()
      this.setUser(user)
    },
  },
})
