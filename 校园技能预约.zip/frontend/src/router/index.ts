import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '../stores/auth'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      redirect: '/app/home',
    },
    {
      path: '/login',
      component: () => import('../views/LoginView.vue'),
      meta: { guestOnly: true, title: '用户登录' },
    },
    {
      path: '/register',
      component: () => import('../views/RegisterView.vue'),
      meta: { guestOnly: true, title: '注册账号' },
    },
    {
      path: '/admin/login',
      component: () => import('../views/AdminLoginView.vue'),
      meta: { guestOnly: true, title: '管理员登录' },
    },
    {
      path: '/app',
      component: () => import('../layouts/MobileShell.vue'),
      meta: { requiresAuth: true, role: 'USER' },
      children: [
        {
          path: 'home',
          component: () => import('../views/HomeView.vue'),
          meta: { title: '首页' },
        },
        {
          path: 'explore',
          component: () => import('../views/ExploreView.vue'),
          meta: { title: '发现' },
        },
        {
          path: 'publish',
          component: () => import('../views/PublishView.vue'),
          meta: { title: '发布' },
        },
        {
          path: 'orders',
          component: () => import('../views/OrdersView.vue'),
          meta: { title: '订单' },
        },
        {
          path: 'profile',
          component: () => import('../views/ProfileView.vue'),
          meta: { title: '我的' },
        },
        {
          path: 'listing/:id',
          component: () => import('../views/ListingDetailView.vue'),
          meta: { title: '详情' },
        },
      ],
    },
    {
      path: '/admin/dashboard',
      component: () => import('../views/AdminDashboardView.vue'),
      meta: { requiresAuth: true, role: 'ADMIN', title: '管理后台' },
    },
  ],
})

router.beforeEach(async (to) => {
  const authStore = useAuthStore()
  const requiresAuth = to.matched.some((item) => item.meta.requiresAuth)
  const guestOnly = to.matched.some((item) => item.meta.guestOnly)
  const role = to.meta.role as 'USER' | 'ADMIN' | undefined

  if (requiresAuth && !authStore.isAuthenticated) {
    return role === 'ADMIN' ? '/admin/login' : '/login'
  }

  if (role === 'USER' && authStore.role !== 'USER') {
    return '/login'
  }

  if (role === 'ADMIN' && authStore.role !== 'ADMIN') {
    return '/admin/login'
  }

  if (guestOnly && authStore.isAuthenticated) {
    return authStore.role === 'ADMIN' ? '/admin/dashboard' : '/app/home'
  }

  return true
})

export default router
