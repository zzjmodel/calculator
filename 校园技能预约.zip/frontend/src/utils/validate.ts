const isBlank = (value: string | null | undefined) => !value || !value.trim()

export const requireText = (value: string | null | undefined, message: string) => {
  if (isBlank(value)) {
    throw new Error(message)
  }
}

export const requirePhone = (value: string | null | undefined, message = '请输入正确的手机号') => {
  requireText(value, message)
  if (!/^1\d{10}$/.test(value!.trim())) {
    throw new Error(message)
  }
}

export const requirePassword = (value: string | null | undefined, message = '密码长度需为 6 到 20 位') => {
  requireText(value, '请输入密码')
  const length = value!.trim().length
  if (length < 6 || length > 20) {
    throw new Error(message)
  }
}

export const requireNumber = (value: number, message: string) => {
  if (Number.isNaN(value)) {
    throw new Error(message)
  }
}
