export const toLabel = (value: string | null | undefined, map: Record<string, string>) => {
  if (!value) {
    return '-'
  }
  return map[value] ?? value
}

export const formatTime = (value: string | null | undefined) => {
  if (!value) {
    return '-'
  }
  return new Date(value).toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export const formatPrice = (value: number | string | null | undefined) => {
  const amount = Number(value ?? 0)
  return `￥${amount.toFixed(2)}`
}

export const readError = (error: unknown) => {
  if (typeof error === 'string') {
    return error
  }
  if (error && typeof error === 'object' && 'message' in error && typeof error.message === 'string') {
    return error.message
  }
  return '操作失败，请稍后再试'
}
