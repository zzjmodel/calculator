import axios from 'axios'
import type { ApiResponse } from '../types'

const client = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:18080',
  timeout: 10000,
})

client.interceptors.request.use((config) => {
  const token = localStorage.getItem('campus-share-token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export const unwrap = async <T>(promise: Promise<{ data: ApiResponse<T> }>) => {
  try {
    const response = await promise
    if (!response.data.success) {
      throw new Error(response.data.message || '请求失败')
    }
    return response.data.data
  } catch (error) {
    if (axios.isAxiosError(error)) {
      const message = error.response?.data?.message ?? '网络请求失败，请检查服务是否启动'
      throw new Error(message)
    }
    throw error
  }
}

export default client
