<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { useRoute } from 'vue-router'
import { Flag, Star } from 'lucide-vue-next'
import { api } from '../api/services'
import EmptyState from '../components/EmptyState.vue'
import StatusBanner from '../components/StatusBanner.vue'
import { handoffMethodLabels, listingTypeLabels } from '../constants/labels'
import { useAuthStore } from '../stores/auth'
import type { Listing, Review } from '../types'
import { formatPrice, readError, toLabel } from '../utils/format'
import { requirePhone, requireText } from '../utils/validate'

const route = useRoute()
const authStore = useAuthStore()
const listing = ref<Listing | null>(null)
const reviews = ref<Review[]>([])
const errorText = ref('')
const successText = ref('')
const orderForm = reactive({
  note: '',
  tradeLocation: '',
  contactPhone: '',
  handoffMethod: 'MEETUP',
})
const reviewForm = reactive({
  orderId: '',
  rating: 5,
  content: '',
})
const reportForm = reactive({
  reason: '',
})

const load = async () => {
  errorText.value = ''
  try {
    const id = Number(route.params.id)
    listing.value = await api.listingDetail(id)
    reviews.value = await api.userReviews(listing.value.userId)
    orderForm.tradeLocation = authStore.user?.tradeLocation ?? ''
    orderForm.contactPhone = authStore.user?.phone ?? ''
  } catch (error) {
    errorText.value = readError(error)
  }
}

onMounted(load)

const createOrder = async () => {
  if (!listing.value) return
  successText.value = ''
  errorText.value = ''
  try {
    requireText(orderForm.tradeLocation, '请输入线下交易地点')
    requirePhone(orderForm.contactPhone)
    await api.createOrder({
      listingId: listing.value.id,
      note: orderForm.note,
      tradeLocation: orderForm.tradeLocation,
      contactPhone: orderForm.contactPhone,
      handoffMethod: orderForm.handoffMethod,
    })
    successText.value = '订单已创建，请到订单页继续处理。'
  } catch (error) {
    errorText.value = readError(error)
  }
}

const submitReview = async () => {
  successText.value = ''
  errorText.value = ''
  try {
    requireText(reviewForm.orderId, '请输入已完成订单编号')
    requireText(reviewForm.content, '请输入评价内容')
    await api.submitReview({
      orderId: Number(reviewForm.orderId),
      rating: reviewForm.rating,
      content: reviewForm.content,
    })
    successText.value = '评价已提交。'
    if (listing.value) {
      reviews.value = await api.userReviews(listing.value.userId)
    }
  } catch (error) {
    errorText.value = readError(error)
  }
}

const submitReport = async () => {
  if (!listing.value) return
  successText.value = ''
  errorText.value = ''
  try {
    requireText(reportForm.reason, '请描述举报原因')
    await api.createReport({
      targetType: 'LISTING',
      targetId: listing.value.id,
      reason: reportForm.reason,
    })
    successText.value = '举报已提交，管理员会尽快处理。'
    reportForm.reason = ''
  } catch (error) {
    errorText.value = readError(error)
  }
}
</script>

<template>
  <div v-if="listing" class="space-y-4">
    <section class="card rounded-[28px] p-5">
      <div class="flex items-start justify-between gap-3">
        <div>
          <p class="text-xs font-medium" style="color: var(--primary)">{{ toLabel(listing.type, listingTypeLabels) }}</p>
          <h2 class="mt-2 text-xl font-semibold leading-8">{{ listing.title }}</h2>
        </div>
        <span class="rounded-full px-3 py-1 text-sm font-semibold" style="background: var(--primary-soft); color: var(--primary)">
          {{ formatPrice(listing.price) }}
        </span>
      </div>
      <p class="mt-4 text-sm leading-7 muted">{{ listing.description }}</p>
      <div class="mt-4 space-y-2 text-sm">
        <p>发布者：{{ listing.userNickname }}</p>
        <p>分类：{{ listing.categoryName || '-' }}</p>
        <p>地点：{{ listing.location }}</p>
        <p>联系方式：{{ listing.contact }}</p>
        <p>时间说明：{{ listing.appointmentTime || '-' }}</p>
      </div>
    </section>

    <section v-if="authStore.user && authStore.user.id !== listing.userId" class="card rounded-[28px] p-5">
      <h3 class="section-title">发起预约 / 交易</h3>
      <div class="mt-4 space-y-3">
        <select v-model="orderForm.handoffMethod" class="field">
          <option value="MEETUP">线下约见</option>
          <option value="SELF_PICKUP">校内自提</option>
        </select>
        <input v-model="orderForm.tradeLocation" class="field" placeholder="线下交易地点" />
        <input v-model="orderForm.contactPhone" class="field" placeholder="联系电话" />
        <textarea v-model="orderForm.note" class="field min-h-[100px]" placeholder="补充说明，例如需求细节或见面时间" />
      </div>
      <p class="mt-3 text-sm muted">当前交接方式：{{ toLabel(orderForm.handoffMethod, handoffMethodLabels) }}</p>
      <button class="btn-primary mt-4 w-full" @click="createOrder">提交订单</button>
    </section>

    <section class="card rounded-[28px] p-5">
      <h3 class="section-title">用户评价</h3>
      <div v-if="reviews.length" class="mt-4 space-y-3">
        <div v-for="item in reviews" :key="item.id" class="rounded-2xl border p-4" style="border-color: var(--line)">
          <div class="flex items-center justify-between">
            <p class="text-sm font-semibold">{{ item.reviewerNickname }}</p>
            <span class="inline-flex items-center gap-1 text-sm" style="color: var(--warning)">
              <Star class="h-4 w-4 fill-current" />
              {{ item.rating }}
            </span>
          </div>
          <p class="mt-2 text-sm muted">{{ item.content }}</p>
        </div>
      </div>
      <EmptyState v-else class="mt-4" title="暂时还没有评价" description="完成订单后，买卖双方都可以留下评分和文字评价。" />
    </section>

    <section class="card rounded-[28px] p-5">
      <h3 class="section-title">提交评价</h3>
      <div class="mt-4 space-y-3">
        <input v-model="reviewForm.orderId" class="field" placeholder="请输入已完成订单编号" />
        <select v-model.number="reviewForm.rating" class="field">
          <option :value="5">5 分</option>
          <option :value="4">4 分</option>
          <option :value="3">3 分</option>
          <option :value="2">2 分</option>
          <option :value="1">1 分</option>
        </select>
        <textarea v-model="reviewForm.content" class="field min-h-[100px]" placeholder="请输入评价内容" />
      </div>
      <button class="btn-secondary mt-4 w-full" @click="submitReview">提交评价</button>
    </section>

    <section class="card rounded-[28px] p-5">
      <div class="flex items-center gap-2">
        <Flag class="h-4 w-4" style="color: var(--danger)" />
        <h3 class="section-title">举报信息</h3>
      </div>
      <textarea v-model="reportForm.reason" class="field mt-4 min-h-[100px]" placeholder="请描述举报原因" />
      <button class="btn-secondary mt-4 w-full" @click="submitReport">提交举报</button>
    </section>

    <StatusBanner v-if="successText" type="success" :text="successText" />
    <StatusBanner v-if="errorText" type="error" :text="errorText" />
  </div>

  <EmptyState v-else title="正在加载详情" description="如果长时间没有内容，请确认后端服务已启动并且当前信息仍然存在。" />
</template>
