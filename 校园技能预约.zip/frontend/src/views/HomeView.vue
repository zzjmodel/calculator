<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { ChartColumnBig, ShieldCheck, Sparkles, Store } from 'lucide-vue-next'
import { RouterLink } from 'vue-router'
import { api } from '../api/services'
import EmptyState from '../components/EmptyState.vue'
import StatusBanner from '../components/StatusBanner.vue'
import ListingCard from '../components/ListingCard.vue'
import { listingTypeLabels } from '../constants/labels'
import type { Category, HomeData } from '../types'
import { readError, toLabel } from '../utils/format'

const data = ref<HomeData | null>(null)
const categories = ref<Category[]>([])
const loading = ref(false)
const errorText = ref('')

const load = async () => {
  loading.value = true
  errorText.value = ''
  try {
    const [homeData, categoryData] = await Promise.all([api.home(), api.categories()])
    data.value = homeData
    categories.value = categoryData
  } catch (error) {
    errorText.value = readError(error)
  } finally {
    loading.value = false
  }
}

onMounted(load)

const statCards = [
  { key: 'userCount', label: '平台用户', icon: ShieldCheck },
  { key: 'listingCount', label: '上架信息', icon: Store },
  { key: 'orderCount', label: '订单总数', icon: ChartColumnBig },
  { key: 'completedOrderCount', label: '已完成', icon: Sparkles },
]

const hotCategories = computed(() => categories.value.slice(0, 6))
</script>

<template>
  <div class="space-y-4">
    <section class="card rounded-[28px] p-5">
      <p class="text-xs uppercase tracking-[0.28em] muted">Campus Market</p>
      <h2 class="mt-3 text-2xl font-semibold leading-9">校内技能与闲置物品共享平台</h2>
      <p class="mt-3 text-sm leading-7 muted">
        用一个手机端 Web 完成实名、发布、预约、交易、评价和后台管理。
      </p>
    </section>

    <section class="grid grid-cols-2 gap-3">
      <div v-for="item in statCards" :key="item.key" class="card rounded-[24px] p-4">
        <component :is="item.icon" class="h-5 w-5" style="color: var(--primary)" />
        <p class="mt-3 text-xs muted">{{ item.label }}</p>
        <p class="mt-2 text-xl font-semibold">{{ data?.stats?.[item.key] ?? 0 }}</p>
      </div>
    </section>

    <section class="card rounded-[28px] p-5">
      <div class="flex items-center justify-between">
        <h3 class="section-title">平台公告</h3>
        <span v-if="loading" class="text-xs muted">加载中...</span>
      </div>
      <StatusBanner v-if="errorText" class="mt-3" type="error" :text="errorText" />
      <div v-if="data?.announcements?.length" class="mt-4 space-y-3">
        <div v-for="item in data.announcements" :key="item.id" class="rounded-2xl border px-4 py-3" style="border-color: var(--line)">
          <div class="flex items-center gap-2">
            <span v-if="item.pinned" class="rounded-full px-2 py-1 text-[10px] font-semibold" style="background: var(--primary-soft); color: var(--primary)">置顶</span>
            <h4 class="text-sm font-semibold">{{ item.title }}</h4>
          </div>
          <p class="mt-2 text-sm leading-6 muted">{{ item.content }}</p>
        </div>
      </div>
      <p v-else class="mt-4 text-sm muted">暂无公告。</p>
    </section>

    <section class="card rounded-[28px] p-5">
      <div class="flex items-center justify-between">
        <h3 class="section-title">热门分类</h3>
        <RouterLink to="/app/explore" class="text-sm font-medium" style="color: var(--primary)">全部查看</RouterLink>
      </div>
      <div class="mt-4 grid grid-cols-2 gap-3">
        <div v-for="item in hotCategories" :key="item.id" class="rounded-[22px] border px-4 py-3" style="border-color: var(--line); background: #fff8ef;">
          <p class="text-xs muted">{{ toLabel(item.type, listingTypeLabels) }}</p>
          <p class="mt-1 text-sm font-semibold">{{ item.name }}</p>
        </div>
      </div>
    </section>

    <section class="space-y-3">
      <div class="flex items-center justify-between px-1">
        <h3 class="section-title">精选信息</h3>
        <RouterLink to="/app/explore" class="text-sm font-medium" style="color: var(--primary)">去发现</RouterLink>
      </div>
      <ListingCard v-for="item in data?.featuredListings ?? []" :key="item.id" :item="item" />
      <EmptyState
        v-if="!data?.featuredListings?.length && !loading"
        title="暂时没有精选信息"
        description="启动后端后会自动注入演示数据；如果你手动清理过数据，也可以重新发布内容。"
      />
    </section>
  </div>
</template>
