<script setup lang="ts">
import { onMounted, reactive, ref, watch } from 'vue'
import ListingCard from '../components/ListingCard.vue'
import { api } from '../api/services'
import EmptyState from '../components/EmptyState.vue'
import StatusBanner from '../components/StatusBanner.vue'
import { defaultTypeTabs } from '../constants/labels'
import type { Category, Listing } from '../types'
import { readError } from '../utils/format'

const categories = ref<Category[]>([])
const listings = ref<Listing[]>([])
const loading = ref(false)
const errorText = ref('')
const filters = reactive({
  keyword: '',
  type: '',
  categoryId: '',
})

const loadCategories = async () => {
  categories.value = await api.categories(filters.type || undefined)
}

const loadListings = async () => {
  loading.value = true
  errorText.value = ''
  try {
    listings.value = await api.listings({
      keyword: filters.keyword || undefined,
      type: filters.type || undefined,
      categoryId: filters.categoryId || undefined,
    })
  } catch (error) {
    errorText.value = readError(error)
  } finally {
    loading.value = false
  }
}

watch(
  () => filters.type,
  async () => {
    filters.categoryId = ''
    await loadCategories()
    await loadListings()
  },
)

onMounted(async () => {
  await loadCategories()
  await loadListings()
})
</script>

<template>
  <div class="space-y-4">
    <section class="card rounded-[28px] p-5">
      <input v-model="filters.keyword" class="field" placeholder="搜索技能、物品或求助关键词" @keyup.enter="loadListings" />
      <div class="mt-4 flex gap-2 overflow-x-auto pb-1">
        <button
          v-for="tab in defaultTypeTabs"
          :key="tab.value"
          class="rounded-full px-4 py-2 text-sm font-medium whitespace-nowrap"
          :class="filters.type === tab.value ? 'text-white' : 'muted'"
          :style="filters.type === tab.value ? 'background: linear-gradient(135deg, #c55b33 0%, #d2813e 100%);' : 'background: #fff6eb; border: 1px solid var(--line)'"
          @click="filters.type = tab.value"
        >
          {{ tab.label }}
        </button>
      </div>
      <select v-model="filters.categoryId" class="field mt-4" @change="loadListings">
        <option value="">全部分类</option>
        <option v-for="item in categories" :key="item.id" :value="item.id">{{ item.name }}</option>
      </select>
    </section>

    <StatusBanner v-if="errorText" type="error" :text="errorText" />
    <p v-if="loading" class="text-sm muted">正在加载信息...</p>

    <ListingCard v-for="item in listings" :key="item.id" :item="item" />
    <EmptyState v-if="!listings.length && !loading" title="没有找到匹配内容" description="可以试着更换分类、清空关键词，或者先去发布页创建一条信息。" />
  </div>
</template>
