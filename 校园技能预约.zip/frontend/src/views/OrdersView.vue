<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { api } from '../api/services'
import EmptyState from '../components/EmptyState.vue'
import StatusBanner from '../components/StatusBanner.vue'
import { handoffMethodLabels, orderStatusLabels } from '../constants/labels'
import { useAuthStore } from '../stores/auth'
import type { Order } from '../types'
import { formatTime, toLabel, readError } from '../utils/format'

const authStore = useAuthStore()
const orders = ref<Order[]>([])
const loading = ref(false)
const errorText = ref('')
const actionLoadingId = ref<number | null>(null)

const load = async () => {
  loading.value = true
  errorText.value = ''
  try {
    orders.value = await api.myOrders()
  } catch (error) {
    errorText.value = readError(error)
  } finally {
    loading.value = false
  }
}

onMounted(load)

const act = async (type: 'confirm' | 'cancel' | 'complete', id: number) => {
  actionLoadingId.value = id
  try {
    if (type === 'confirm') {
      await api.confirmOrder(id)
    } else if (type === 'cancel') {
      await api.cancelOrder(id)
    } else {
      await api.completeOrder(id, { offlinePaid: true })
    }
    await load()
  } catch (error) {
    errorText.value = readError(error)
  } finally {
    actionLoadingId.value = null
  }
}
</script>

<template>
  <div class="space-y-4">
    <StatusBanner v-if="errorText" type="error" :text="errorText" />
    <p v-if="loading" class="text-sm muted">订单加载中...</p>

    <div v-for="item in orders" :key="item.id" class="card rounded-[26px] p-5">
      <div class="flex items-start justify-between gap-4">
        <div>
          <p class="text-xs muted">订单号 #{{ item.id }}</p>
          <h3 class="mt-2 text-sm font-semibold">{{ item.listingTitle }}</h3>
        </div>
        <span class="rounded-full px-3 py-1 text-xs font-semibold" style="background: var(--primary-soft); color: var(--primary)">
          {{ toLabel(item.status, orderStatusLabels) }}
        </span>
      </div>
      <div class="mt-4 space-y-2 text-sm muted">
        <p>买方：{{ item.buyerNickname }}</p>
        <p>卖方：{{ item.sellerNickname }}</p>
        <p>交易地点：{{ item.tradeLocation || '-' }}</p>
        <p>联系电话：{{ item.contactPhone || '-' }}</p>
        <p>交接方式：{{ toLabel(item.handoffMethod, handoffMethodLabels) }}</p>
        <p v-if="item.pickupCode">自提码：{{ item.pickupCode }}</p>
        <p>创建时间：{{ formatTime(item.createdAt) }}</p>
        <p>线下支付：{{ item.offlinePaid ? '已登记' : '未登记' }}</p>
      </div>

      <div class="mt-4 flex gap-2">
        <button
          v-if="item.status === 'PENDING_CONFIRMATION' && authStore.user?.id === item.sellerId"
          class="btn-secondary flex-1"
          :disabled="actionLoadingId === item.id"
          @click="act('confirm', item.id)"
        >
          确认订单
        </button>
        <button
          v-if="['PENDING_CONFIRMATION', 'CONFIRMED'].includes(item.status)"
          class="btn-secondary flex-1"
          :disabled="actionLoadingId === item.id"
          @click="act('cancel', item.id)"
        >
          取消订单
        </button>
        <button
          v-if="item.status === 'CONFIRMED' && authStore.user?.id === item.sellerId"
          class="btn-primary flex-1"
          :disabled="actionLoadingId === item.id"
          @click="act('complete', item.id)"
        >
          登记线下支付并完成
        </button>
      </div>
    </div>

    <EmptyState v-if="!orders.length && !loading" title="暂无订单" description="下单、确认、完成交易后，这里会沉淀你的预约和交易记录。" />
  </div>
</template>
