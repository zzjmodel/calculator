<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useRouter, RouterLink } from 'vue-router'
import { api } from '../api/services'
import StatusBanner from '../components/StatusBanner.vue'
import { useAuthStore } from '../stores/auth'
import { readError } from '../utils/format'
import { requirePassword, requireText } from '../utils/validate'

const router = useRouter()
const authStore = useAuthStore()
const form = reactive({
  account: '',
  password: '',
})
const loading = ref(false)
const errorText = ref('')

const submit = async () => {
  loading.value = true
  errorText.value = ''
  try {
    requireText(form.account, '请输入学号或手机号')
    requirePassword(form.password)
    const session = await api.login(form)
    authStore.setSession(session)
    router.push('/app/home')
  } catch (error) {
    errorText.value = readError(error)
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="mobile-page flex min-h-screen items-center justify-center px-5 py-10">
    <div class="card w-full rounded-[28px] p-6">
      <p class="text-xs uppercase tracking-[0.3em] muted">User Login</p>
      <h1 class="mt-3 text-2xl font-semibold">登录校园共享平台</h1>
      <p class="mt-2 text-sm muted">学号或手机号登录，进入技能预约、闲置交易和互助信息。</p>

      <div class="mt-6 space-y-3">
        <input v-model="form.account" class="field" placeholder="请输入学号或手机号" />
        <input v-model="form.password" class="field" placeholder="请输入密码" type="password" />
      </div>

      <StatusBanner v-if="errorText" class="mt-3" type="error" :text="errorText" />

      <button class="btn-primary mt-6 w-full" :disabled="loading" @click="submit">
        {{ loading ? '登录中...' : '立即登录' }}
      </button>

      <div class="mt-4 flex items-center justify-between text-sm muted">
        <RouterLink to="/register">还没有账号？去注册</RouterLink>
        <RouterLink to="/admin/login">管理员入口</RouterLink>
      </div>
    </div>
  </div>
</template>
