<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { api } from '../api/services'
import EmptyState from '../components/EmptyState.vue'
import StatusBanner from '../components/StatusBanner.vue'
import { certificationStatusLabels, listingStatusLabels, listingTypeLabels, orderStatusLabels, reportStatusLabels } from '../constants/labels'
import { useAuthStore } from '../stores/auth'
import type { AdminDashboard, AdminUser, Announcement, Category, Certification, Listing, ReportItem } from '../types'
import { formatPrice, formatTime, readError, toLabel } from '../utils/format'
import { requireNumber, requireText } from '../utils/validate'

const router = useRouter()
const authStore = useAuthStore()
const dashboard = ref<AdminDashboard | null>(null)
const users = ref<AdminUser[]>([])
const categories = ref<Category[]>([])
const certifications = ref<Certification[]>([])
const reports = ref<ReportItem[]>([])
const announcements = ref<Announcement[]>([])
const listings = ref<Listing[]>([])
const statsType = ref('')
const announcementForm = reactive({
  title: '',
  content: '',
  pinned: true,
})
const categoryForm = reactive({
  name: '',
  type: 'SKILL',
  sortOrder: 1,
})
const editingCategoryId = ref<number | null>(null)
const loading = ref(false)
const errorText = ref('')
const successText = ref('')

const load = async () => {
  loading.value = true
  errorText.value = ''
  try {
    const [dashboardData, usersData, categoryData, certificationData, reportData, announcementData, listingData] = await Promise.all([
      api.adminDashboard(statsType.value || undefined),
      api.adminUsers(),
      api.adminCategories(),
      api.certificationList(),
      api.reportList(),
      api.announcements(),
      api.adminListings(statsType.value || undefined),
    ])
    dashboard.value = dashboardData
    users.value = usersData
    categories.value = categoryData
    certifications.value = certificationData
    reports.value = reportData
    announcements.value = announcementData
    listings.value = listingData
  } catch (error) {
    errorText.value = readError(error)
  } finally {
    loading.value = false
  }
}

onMounted(load)

const reviewCertification = async (id: number, status: 'APPROVED' | 'REJECTED') => {
  try {
    await api.reviewCertification(id, { status, remark: status === 'APPROVED' ? '资料核验通过' : '资料不完整，请重新提交' })
    successText.value = '认证审核已完成。'
    await load()
  } catch (error) {
    errorText.value = readError(error)
  }
}

const handleReport = async (id: number) => {
  try {
    await api.handleReport(id, { handleResult: '已记录并处理，相关内容将进一步复核。' })
    successText.value = '举报已处理。'
    await load()
  } catch (error) {
    errorText.value = readError(error)
  }
}

const publishAnnouncement = async () => {
  try {
    await api.createAnnouncement(announcementForm)
    successText.value = '公告发布成功。'
    announcementForm.title = ''
    announcementForm.content = ''
    announcementForm.pinned = true
    await load()
  } catch (error) {
    errorText.value = readError(error)
  }
}

const categoryTypeOptions = computed(() => [
  { label: '技能服务', value: 'SKILL' },
  { label: '闲置物品', value: 'ITEM' },
  { label: '求助互助', value: 'HELP' },
])

const statsTypeOptions = computed(() => [
  { label: '全部', value: '' },
  { label: '技能服务', value: 'SKILL' },
  { label: '闲置物品', value: 'ITEM' },
  { label: '求助互助', value: 'HELP' },
])

const maxListingTypeTotal = computed(() => Math.max(...(dashboard.value?.listingTypeStats?.map((item) => item.total) ?? [1])))
const maxOrderStatusTotal = computed(() => Math.max(...(dashboard.value?.orderStatusStats?.map((item) => item.total) ?? [1])))
const maxHotCategoryTotal = computed(() => Math.max(...(dashboard.value?.hotCategoryStats?.map((item) => item.total) ?? [1])))
const maxListingTrendTotal = computed(() => Math.max(...(dashboard.value?.recentListingTrend?.map((item) => item.total) ?? [1])))
const maxOrderTrendTotal = computed(() => Math.max(...(dashboard.value?.recentOrderTrend?.map((item) => item.total) ?? [1])))

const toggleUserDisabled = async (id: number) => {
  try {
    await api.toggleUserDisabled(id)
    successText.value = '用户状态已更新。'
    await load()
  } catch (error) {
    errorText.value = readError(error)
  }
}

const changeListingStatus = async (id: number, status: 'PUBLISHED' | 'OFFLINE') => {
  try {
    await api.adminListingStatus(id, status)
    successText.value = status === 'OFFLINE' ? '信息已下架。' : '信息已恢复上架。'
    await load()
  } catch (error) {
    errorText.value = readError(error)
  }
}

const editCategory = (item: Category) => {
  editingCategoryId.value = item.id
  categoryForm.name = item.name
  categoryForm.type = item.type
  categoryForm.sortOrder = item.sortOrder ?? 1
}

const resetCategoryForm = () => {
  editingCategoryId.value = null
  categoryForm.name = ''
  categoryForm.type = 'SKILL'
  categoryForm.sortOrder = 1
}

const saveCategory = async () => {
  try {
    requireText(categoryForm.name, '请输入分类名称')
    requireText(categoryForm.type, '请选择分类类型')
    requireNumber(categoryForm.sortOrder, '请输入排序值')
    if (editingCategoryId.value) {
      await api.updateCategory(editingCategoryId.value, categoryForm)
      successText.value = '分类已更新。'
    } else {
      await api.createCategory(categoryForm)
      successText.value = '分类已创建。'
    }
    resetCategoryForm()
    await load()
  } catch (error) {
    errorText.value = readError(error)
  }
}

const toggleCategoryEnabled = async (id: number) => {
  try {
    await api.toggleCategoryEnabled(id)
    successText.value = '分类状态已更新。'
    await load()
  } catch (error) {
    errorText.value = readError(error)
  }
}

const changeStatsType = async (value: string) => {
  if (statsType.value === value) {
    return
  }
  statsType.value = value
  await load()
}

const logout = () => {
  authStore.clear()
  router.push('/admin/login')
}
</script>

<template>
  <div class="mobile-page px-4 py-5">
    <header class="mb-4 flex items-center justify-between">
      <div>
        <p class="text-xs uppercase tracking-[0.28em] muted">Admin Dashboard</p>
        <h1 class="mt-2 text-2xl font-semibold">管理后台</h1>
      </div>
      <button class="btn-secondary" @click="logout">退出</button>
    </header>

    <StatusBanner v-if="errorText" class="mb-3" type="error" :text="errorText" />
    <StatusBanner v-if="successText" class="mb-3" type="success" :text="successText" />

    <section class="grid grid-cols-2 gap-3">
      <div class="card rounded-[24px] p-4">
        <p class="text-xs muted">平台用户</p>
        <p class="mt-2 text-xl font-semibold">{{ dashboard?.userCount ?? 0 }}</p>
      </div>
      <div class="card rounded-[24px] p-4">
        <p class="text-xs muted">信息总数</p>
        <p class="mt-2 text-xl font-semibold">{{ dashboard?.listingCount ?? 0 }}</p>
      </div>
      <div class="card rounded-[24px] p-4">
        <p class="text-xs muted">待审认证</p>
        <p class="mt-2 text-xl font-semibold">{{ dashboard?.pendingCertificationCount ?? 0 }}</p>
      </div>
      <div class="card rounded-[24px] p-4">
        <p class="text-xs muted">待处理举报</p>
        <p class="mt-2 text-xl font-semibold">{{ dashboard?.pendingReportCount ?? 0 }}</p>
      </div>
    </section>

    <section class="card mt-4 rounded-[28px] p-5">
      <div class="flex items-center justify-between">
        <h2 class="section-title">数据统计</h2>
        <span class="text-xs muted">最近 7 天与当前分布</span>
      </div>

      <div class="mt-4 grid grid-cols-4 gap-2">
        <button
          v-for="item in statsTypeOptions"
          :key="item.value || 'ALL'"
          class="rounded-2xl px-3 py-3 text-sm font-semibold"
          :class="statsType === item.value ? 'text-white' : 'muted'"
          :style="statsType === item.value ? 'background: linear-gradient(135deg, #c55b33 0%, #d2813e 100%);' : 'background: #fff6eb; border: 1px solid var(--line)'"
          @click="changeStatsType(item.value)"
        >
          {{ item.label }}
        </button>
      </div>

      <div class="mt-4 grid gap-4">
        <div class="rounded-[24px] border p-4" style="border-color: var(--line)">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-semibold">信息类型分布</h3>
            <span class="text-xs muted">按发布内容统计</span>
          </div>
          <div v-if="dashboard?.listingTypeStats?.length" class="mt-4 space-y-3">
            <div v-for="item in dashboard.listingTypeStats" :key="item.key">
              <div class="flex items-center justify-between text-sm">
                <span>{{ toLabel(item.label, listingTypeLabels) }}</span>
                <span class="font-semibold">{{ item.total }}</span>
              </div>
              <div class="mt-2 h-2 overflow-hidden rounded-full" style="background:#f3e7d8;">
                <div
                  class="h-full rounded-full"
                  style="background:linear-gradient(90deg, #c55b33 0%, #d98d46 100%);"
                  :style="{ width: `${Math.max((item.total / maxListingTypeTotal) * 100, 8)}%` }"
                />
              </div>
            </div>
          </div>
          <EmptyState v-else class="mt-4" title="暂无统计数据" description="当前还没有发布信息，后续会在这里展示类型分布。" />
        </div>

        <div class="rounded-[24px] border p-4" style="border-color: var(--line)">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-semibold">订单状态分布</h3>
            <span class="text-xs muted">按全部订单统计</span>
          </div>
          <div v-if="dashboard?.orderStatusStats?.length" class="mt-4 space-y-3">
            <div v-for="item in dashboard.orderStatusStats" :key="item.key">
              <div class="flex items-center justify-between text-sm">
                <span>{{ toLabel(item.label, orderStatusLabels) }}</span>
                <span class="font-semibold">{{ item.total }}</span>
              </div>
              <div class="mt-2 h-2 overflow-hidden rounded-full" style="background:#f3e7d8;">
                <div
                  class="h-full rounded-full"
                  style="background:linear-gradient(90deg, #7a8f51 0%, #afc17a 100%);"
                  :style="{ width: `${Math.max((item.total / maxOrderStatusTotal) * 100, 8)}%` }"
                />
              </div>
            </div>
          </div>
          <EmptyState v-else class="mt-4" title="暂无订单统计" description="生成订单后，这里会展示待确认、已完成等状态分布。" />
        </div>

        <div class="rounded-[24px] border p-4" style="border-color: var(--line)">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-semibold">热门分类排行</h3>
            <span class="text-xs muted">按发布数量排序</span>
          </div>
          <div v-if="dashboard?.hotCategoryStats?.length" class="mt-4 space-y-3">
            <div v-for="(item, index) in dashboard.hotCategoryStats" :key="`${item.key}-${index}`">
              <div class="flex items-center justify-between text-sm">
                <span>{{ item.label }}</span>
                <span class="font-semibold">{{ item.total }}</span>
              </div>
              <div class="mt-2 h-2 overflow-hidden rounded-full" style="background:#f3e7d8;">
                <div
                  class="h-full rounded-full"
                  style="background:linear-gradient(90deg, #416d61 0%, #78a79f 100%);"
                  :style="{ width: `${Math.max((item.total / maxHotCategoryTotal) * 100, 8)}%` }"
                />
              </div>
            </div>
          </div>
          <EmptyState v-else class="mt-4" title="暂无分类热度" description="发布信息并选择分类后，这里会显示最活跃的分类。" />
        </div>

        <div class="rounded-[24px] border p-4" style="border-color: var(--line)">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-semibold">近 7 日发布趋势</h3>
            <span class="text-xs muted">每日新增信息</span>
          </div>
          <div v-if="dashboard?.recentListingTrend?.length" class="mt-4 flex items-end gap-2">
            <div v-for="item in dashboard.recentListingTrend" :key="item.date" class="flex min-w-0 flex-1 flex-col items-center">
              <div class="mb-2 text-xs font-semibold">{{ item.total }}</div>
              <div
                class="w-full rounded-t-xl"
                style="min-height: 16px; background: linear-gradient(180deg, #c55b33 0%, #e9b27f 100%);"
                :style="{ height: `${Math.max((item.total / maxListingTrendTotal) * 96, 16)}px` }"
              />
              <div class="mt-2 text-[11px] muted">{{ item.date.slice(5) }}</div>
            </div>
          </div>
          <EmptyState v-else class="mt-4" title="暂无趋势数据" description="最近 7 天新增发布内容会在这里按日期展示。" />
        </div>

        <div class="rounded-[24px] border p-4" style="border-color: var(--line)">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-semibold">近 7 日订单趋势</h3>
            <span class="text-xs muted">每日新增订单</span>
          </div>
          <div v-if="dashboard?.recentOrderTrend?.length" class="mt-4 flex items-end gap-2">
            <div v-for="item in dashboard.recentOrderTrend" :key="item.date" class="flex min-w-0 flex-1 flex-col items-center">
              <div class="mb-2 text-xs font-semibold">{{ item.total }}</div>
              <div
                class="w-full rounded-t-xl"
                style="min-height: 16px; background: linear-gradient(180deg, #7a8f51 0%, #ced7a3 100%);"
                :style="{ height: `${Math.max((item.total / maxOrderTrendTotal) * 96, 16)}px` }"
              />
              <div class="mt-2 text-[11px] muted">{{ item.date.slice(5) }}</div>
            </div>
          </div>
          <EmptyState v-else class="mt-4" title="暂无订单趋势" description="最近 7 天新增订单会在这里按日期展示。" />
        </div>
      </div>
    </section>

    <section class="card mt-4 rounded-[28px] p-5">
      <h2 class="section-title">用户管理</h2>
      <div v-if="users.length" class="mt-4 space-y-3">
        <div v-for="item in users" :key="item.id" class="rounded-2xl border p-4" style="border-color: var(--line)">
          <div class="flex items-center justify-between gap-3">
            <div>
              <p class="text-sm font-semibold">{{ item.nickname }}</p>
              <p class="mt-1 text-xs muted">{{ item.studentId }} · {{ item.phone }}</p>
            </div>
            <span class="text-xs muted">{{ item.disabled ? '已封禁' : '正常' }}</span>
          </div>
          <p class="mt-2 text-sm muted">{{ item.department || '未填写院系' }} {{ item.gradeLevel || '' }}</p>
          <p class="mt-1 text-sm muted">认证状态：{{ toLabel(item.certificationStatus, certificationStatusLabels) }}</p>
          <button class="btn-secondary mt-3 w-full" @click="toggleUserDisabled(item.id)">
            {{ item.disabled ? '解除封禁' : '封禁用户' }}
          </button>
        </div>
      </div>
      <EmptyState v-else class="mt-4" title="暂无用户" description="当前还没有用户注册，先从前台注册一个账号再回来查看。" />
    </section>

    <section class="card mt-4 rounded-[28px] p-5">
      <h2 class="section-title">发布公告</h2>
      <div class="mt-4 space-y-3">
        <input v-model="announcementForm.title" class="field" placeholder="公告标题" />
        <textarea v-model="announcementForm.content" class="field min-h-[100px]" placeholder="公告内容" />
      </div>
      <label class="mt-3 flex items-center gap-2 text-sm muted">
        <input v-model="announcementForm.pinned" type="checkbox" />
        置顶公告
      </label>
      <button class="btn-primary mt-4 w-full" :disabled="loading" @click="publishAnnouncement">发布公告</button>

      <div v-if="announcements.length" class="mt-4 space-y-2">
        <div v-for="item in announcements" :key="item.id" class="rounded-2xl border p-3" style="border-color: var(--line)">
          <div class="flex items-center justify-between gap-3">
            <p class="text-sm font-semibold">{{ item.title }}</p>
            <span class="text-xs muted">{{ formatTime(item.publishedAt) }}</span>
          </div>
          <p class="mt-2 text-sm muted">{{ item.content }}</p>
        </div>
      </div>
      <EmptyState v-else class="mt-4" title="暂无公告" description="可以直接在上方表单发布一条公告，用于演示后台运营能力。" />
    </section>

    <section class="card mt-4 rounded-[28px] p-5">
      <div class="flex items-center justify-between">
        <h2 class="section-title">分类管理</h2>
        <button v-if="editingCategoryId" class="btn-secondary" @click="resetCategoryForm">取消编辑</button>
      </div>
      <div class="mt-4 space-y-3">
        <input v-model="categoryForm.name" class="field" placeholder="分类名称" />
        <select v-model="categoryForm.type" class="field">
          <option v-for="item in categoryTypeOptions" :key="item.value" :value="item.value">{{ item.label }}</option>
        </select>
        <input v-model.number="categoryForm.sortOrder" class="field" type="number" min="1" placeholder="排序值" />
      </div>
      <button class="btn-primary mt-4 w-full" @click="saveCategory">
        {{ editingCategoryId ? '保存分类' : '新增分类' }}
      </button>

      <div v-if="categories.length" class="mt-4 space-y-3">
        <div v-for="item in categories" :key="item.id" class="rounded-2xl border p-4" style="border-color: var(--line)">
          <div class="flex items-center justify-between gap-3">
            <div>
              <p class="text-xs muted">{{ toLabel(item.type, listingTypeLabels) }}</p>
              <p class="mt-1 text-sm font-semibold">{{ item.name }}</p>
            </div>
            <span class="text-xs muted">{{ item.enabled ? '启用中' : '已停用' }}</span>
          </div>
          <p class="mt-2 text-sm muted">排序值：{{ item.sortOrder ?? '-' }}</p>
          <div class="mt-3 flex gap-2">
            <button class="btn-secondary flex-1" @click="editCategory(item)">编辑</button>
            <button class="btn-secondary flex-1" @click="toggleCategoryEnabled(item.id)">
              {{ item.enabled ? '停用' : '启用' }}
            </button>
          </div>
        </div>
      </div>
      <EmptyState v-else class="mt-4" title="暂无分类" description="新增一个分类后，前台发布页和发现页会同步可用。" />
    </section>

    <section class="card mt-4 rounded-[28px] p-5">
      <h2 class="section-title">内容审核与下架</h2>
      <div v-if="listings.length" class="mt-4 space-y-3">
        <div v-for="item in listings" :key="item.id" class="rounded-2xl border p-4" style="border-color: var(--line)">
          <div class="flex items-start justify-between gap-3">
            <div>
              <p class="text-xs font-medium" style="color: var(--primary)">{{ toLabel(item.type, listingTypeLabels) }}</p>
              <p class="mt-1 text-sm font-semibold">{{ item.title }}</p>
            </div>
            <span class="text-xs muted">{{ toLabel(item.status, listingStatusLabels) }}</span>
          </div>
          <p class="mt-2 text-sm muted">{{ item.userNickname }} · {{ item.categoryName || '未分类' }}</p>
          <p class="mt-1 text-sm muted">{{ formatPrice(item.price) }} · {{ item.location }}</p>
          <div class="mt-3 flex gap-2">
            <button
              v-if="item.status === 'PUBLISHED'"
              class="btn-secondary flex-1"
              @click="changeListingStatus(item.id, 'OFFLINE')"
            >
              下架内容
            </button>
            <button
              v-else
              class="btn-primary flex-1"
              @click="changeListingStatus(item.id, 'PUBLISHED')"
            >
              恢复上架
            </button>
          </div>
        </div>
      </div>
      <EmptyState v-else class="mt-4" title="暂无内容" description="发布页创建内容后，这里会展示所有信息并支持后台下架。" />
    </section>

    <section class="card mt-4 rounded-[28px] p-5">
      <h2 class="section-title">实名认证审核</h2>
      <div v-if="certifications.length" class="mt-4 space-y-3">
        <div v-for="item in certifications" :key="item.id" class="rounded-2xl border p-4" style="border-color: var(--line)">
          <div class="flex items-center justify-between">
            <p class="text-sm font-semibold">{{ item.userNickname }} / {{ item.realName }}</p>
            <span class="text-xs muted">{{ toLabel(item.status, certificationStatusLabels) }}</span>
          </div>
          <p class="mt-2 text-sm muted">图片地址：{{ item.studentCardImage }}</p>
          <p v-if="item.remark" class="mt-1 text-sm muted">备注：{{ item.remark }}</p>
          <div v-if="item.status === 'SUBMITTED'" class="mt-3 flex gap-2">
            <button class="btn-primary flex-1" @click="reviewCertification(item.id, 'APPROVED')">通过</button>
            <button class="btn-secondary flex-1" @click="reviewCertification(item.id, 'REJECTED')">驳回</button>
          </div>
        </div>
      </div>
      <EmptyState v-else class="mt-4" title="暂无认证申请" description="前台个人中心提交实名认证后，这里会出现待审核记录。" />
    </section>

    <section class="card mt-4 rounded-[28px] p-5">
      <h2 class="section-title">举报处理</h2>
      <div v-if="reports.length" class="mt-4 space-y-3">
        <div v-for="item in reports" :key="item.id" class="rounded-2xl border p-4" style="border-color: var(--line)">
          <div class="flex items-center justify-between">
            <p class="text-sm font-semibold">{{ item.reporterNickname }}</p>
            <span class="text-xs muted">{{ toLabel(item.status, reportStatusLabels) }}</span>
          </div>
          <p class="mt-2 text-sm muted">目标：{{ item.targetType }} #{{ item.targetId }}</p>
          <p class="mt-1 text-sm muted">原因：{{ item.reason }}</p>
          <p v-if="item.handleResult" class="mt-1 text-sm muted">处理结果：{{ item.handleResult }}</p>
          <button v-if="item.status === 'PENDING'" class="btn-secondary mt-3 w-full" @click="handleReport(item.id)">
            标记为已处理
          </button>
        </div>
      </div>
      <EmptyState v-else class="mt-4" title="暂无举报记录" description="前台详情页提交举报后，管理员可以在这里统一处理。" />
    </section>
  </div>
</template>
