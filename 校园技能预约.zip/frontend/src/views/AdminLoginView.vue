<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useRouter, RouterLink } from 'vue-router'
import { api } from '../api/services'
import StatusBanner from '../components/StatusBanner.vue'
import { useAuthStore } from '../stores/auth'
import { readError } from '../utils/format'
import { requirePassword, requireText } from '../utils/validate'

const router = useRouter()
const authStore = useAuthStore()
const form = reactive({
  username: 'admin',
  password: '123456',
})
const loading = ref(false)
const errorText = ref('')

const submit = async () => {
  loading.value = true
  errorText.value = ''
  try {
    requireText(form.username, '请输入管理员账号')
    requirePassword(form.password)
    const session = await api.adminLogin(form)
    authStore.setSession(session)
    router.push('/admin/dashboard')
  } catch (error) {
    errorText.value = readError(error)
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="mobile-page flex min-h-screen items-center justify-center px-5 py-10">
    <div class="card w-full rounded-[28px] p-6">
      <p class="text-xs uppercase tracking-[0.3em] muted">Admin Console</p>
      <h1 class="mt-3 text-2xl font-semibold">后台管理登录</h1>
      <p class="mt-2 text-sm muted">默认演示账号：admin / 123456</p>

      <div class="mt-6 space-y-3">
        <input v-model="form.username" class="field" placeholder="管理员账号" />
        <input v-model="form.password" class="field" type="password" placeholder="管理员密码" />
      </div>

      <StatusBanner v-if="errorText" class="mt-3" type="error" :text="errorText" />

      <button class="btn-primary mt-6 w-full" :disabled="loading" @click="submit">
        {{ loading ? '登录中...' : '进入后台' }}
      </button>

      <RouterLink to="/login" class="mt-4 block text-center text-sm muted">返回用户登录</RouterLink>
    </div>
  </div>
</template>
