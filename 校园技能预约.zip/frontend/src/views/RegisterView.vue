<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useRouter, RouterLink } from 'vue-router'
import { api } from '../api/services'
import StatusBanner from '../components/StatusBanner.vue'
import { useAuthStore } from '../stores/auth'
import { readError } from '../utils/format'
import { requirePassword, requirePhone, requireText } from '../utils/validate'

const router = useRouter()
const authStore = useAuthStore()
const form = reactive({
  studentId: '',
  phone: '',
  nickname: '',
  password: '',
})
const loading = ref(false)
const errorText = ref('')

const submit = async () => {
  loading.value = true
  errorText.value = ''
  try {
    requireText(form.studentId, '请输入学号')
    requirePhone(form.phone)
    requireText(form.nickname, '请输入昵称')
    requirePassword(form.password)
    const session = await api.register(form)
    authStore.setSession(session)
    router.push('/app/home')
  } catch (error) {
    errorText.value = readError(error)
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="mobile-page flex min-h-screen items-center justify-center px-5 py-10">
    <div class="card w-full rounded-[28px] p-6">
      <p class="text-xs uppercase tracking-[0.3em] muted">Register</p>
      <h1 class="mt-3 text-2xl font-semibold">创建你的校园账号</h1>

      <div class="mt-6 space-y-3">
        <input v-model="form.studentId" class="field" placeholder="请输入学号" />
        <input v-model="form.phone" class="field" placeholder="请输入手机号" />
        <input v-model="form.nickname" class="field" placeholder="请输入昵称" />
        <input v-model="form.password" class="field" type="password" placeholder="请输入 6-20 位密码" />
      </div>

      <StatusBanner v-if="errorText" class="mt-3" type="error" :text="errorText" />

      <button class="btn-primary mt-6 w-full" :disabled="loading" @click="submit">
        {{ loading ? '注册中...' : '注册并进入平台' }}
      </button>

      <RouterLink to="/login" class="mt-4 block text-center text-sm muted">已有账号，返回登录</RouterLink>
    </div>
  </div>
</template>
