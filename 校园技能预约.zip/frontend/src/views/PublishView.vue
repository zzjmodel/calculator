<script setup lang="ts">
import { onMounted, reactive, ref, watch } from 'vue'
import { api } from '../api/services'
import EmptyState from '../components/EmptyState.vue'
import StatusBanner from '../components/StatusBanner.vue'
import { listingStatusLabels, listingTypeLabels } from '../constants/labels'
import type { Category, Listing } from '../types'
import { formatPrice, readError, toLabel } from '../utils/format'
import { requireNumber, requireText } from '../utils/validate'

const form = reactive({
  type: 'SKILL',
  categoryId: '',
  title: '',
  description: '',
  images: '',
  price: 0,
  stock: 1,
  location: '',
  contact: '',
  appointmentTime: '',
})
const categories = ref<Category[]>([])
const myListings = ref<Listing[]>([])
const editingId = ref<number | null>(null)
const loading = ref(false)
const message = ref('')
const errorText = ref('')

const loadCategories = async () => {
  categories.value = await api.categories(form.type)
}

const loadMyListings = async () => {
  myListings.value = await api.myListings()
}

watch(
  () => form.type,
  async () => {
    form.categoryId = ''
    await loadCategories()
  },
)

onMounted(async () => {
  await loadCategories()
  await loadMyListings()
})

const resetForm = () => {
  editingId.value = null
  form.type = 'SKILL'
  form.categoryId = ''
  form.title = ''
  form.description = ''
  form.images = ''
  form.price = 0
  form.stock = 1
  form.location = ''
  form.contact = ''
  form.appointmentTime = ''
}

const submit = async () => {
  loading.value = true
  errorText.value = ''
  message.value = ''
  try {
    requireText(form.title, '请输入标题')
    requireText(form.description, '请输入内容描述')
    requireText(form.location, '请输入交易或见面地点')
    requireText(form.contact, '请输入联系方式')
    requireNumber(form.price, '请输入价格')
    const payload = {
      ...form,
      categoryId: form.categoryId ? Number(form.categoryId) : null,
    }
    if (editingId.value) {
      await api.updateListing(editingId.value, payload)
      message.value = '发布信息已更新。'
    } else {
      await api.createListing(payload)
      message.value = '发布成功，可以去发现页查看。'
    }
    resetForm()
    await loadCategories()
    await loadMyListings()
  } catch (error) {
    errorText.value = readError(error)
  } finally {
    loading.value = false
  }
}

const editListing = async (item: Listing) => {
  editingId.value = item.id
  form.type = item.type
  await loadCategories()
  form.categoryId = item.categoryId ? String(item.categoryId) : ''
  form.title = item.title
  form.description = item.description
  form.images = item.images ?? ''
  form.price = item.price
  form.stock = item.stock
  form.location = item.location
  form.contact = item.contact
  form.appointmentTime = item.appointmentTime ?? ''
}

const changeStatus = async (item: Listing, status: 'PUBLISHED' | 'OFFLINE') => {
  errorText.value = ''
  message.value = ''
  try {
    await api.changeListingStatus(item.id, status)
    message.value = status === 'OFFLINE' ? '信息已下架。' : '信息已重新上架。'
    await loadMyListings()
  } catch (error) {
    errorText.value = readError(error)
  }
}
</script>

<template>
  <div class="space-y-4">
    <section class="card rounded-[28px] p-5">
      <div class="flex items-center justify-between">
        <h2 class="section-title">{{ editingId ? '编辑发布信息' : '统一发布入口' }}</h2>
        <button v-if="editingId" class="btn-secondary" @click="resetForm">取消编辑</button>
      </div>
      <div class="mt-4 grid grid-cols-3 gap-2">
        <button
          v-for="item in [
            { label: '技能服务', value: 'SKILL' },
            { label: '闲置物品', value: 'ITEM' },
            { label: '求助互助', value: 'HELP' },
          ]"
          :key="item.value"
          class="rounded-2xl px-3 py-3 text-sm font-semibold"
          :class="form.type === item.value ? 'text-white' : 'muted'"
          :style="form.type === item.value ? 'background: linear-gradient(135deg, #c55b33 0%, #d2813e 100%);' : 'background: #fff6eb; border: 1px solid var(--line)'"
          @click="form.type = item.value"
        >
          {{ item.label }}
        </button>
      </div>

      <div class="mt-4 space-y-3">
        <select v-model="form.categoryId" class="field">
          <option value="">请选择分类</option>
          <option v-for="item in categories" :key="item.id" :value="item.id">{{ item.name }}</option>
        </select>
        <input v-model="form.title" class="field" placeholder="标题" />
        <textarea v-model="form.description" class="field min-h-[120px]" placeholder="描述你的服务、物品或求助内容" />
        <input v-model="form.images" class="field" placeholder="图片地址，多个图片可用逗号分隔" />
        <div class="grid grid-cols-2 gap-3">
          <input v-model.number="form.price" class="field" type="number" min="0" step="0.01" placeholder="价格" />
          <input v-model.number="form.stock" class="field" type="number" min="1" step="1" placeholder="库存" />
        </div>
        <input v-model="form.location" class="field" placeholder="交易或见面地点" />
        <input v-model="form.contact" class="field" placeholder="联系方式" />
        <input v-model="form.appointmentTime" class="field" placeholder="可预约时间或交易时间说明" />
      </div>

      <StatusBanner v-if="message" class="mt-3" type="success" :text="message" />
      <StatusBanner v-if="errorText" class="mt-3" type="error" :text="errorText" />

      <button class="btn-primary mt-5 w-full" :disabled="loading" @click="submit">
        {{ loading ? '提交中...' : editingId ? '保存修改' : '提交发布' }}
      </button>
    </section>

    <section class="card rounded-[28px] p-5">
      <div class="flex items-center justify-between">
        <h2 class="section-title">我的发布</h2>
        <span class="text-sm muted">{{ myListings.length }} 条</span>
      </div>

      <div v-if="myListings.length" class="mt-4 space-y-3">
        <div v-for="item in myListings" :key="item.id" class="rounded-[24px] border p-4" style="border-color: var(--line)">
          <div class="flex items-start justify-between gap-3">
            <div>
              <p class="text-xs font-medium" style="color: var(--primary)">{{ toLabel(item.type, listingTypeLabels) }}</p>
              <h3 class="mt-1 text-sm font-semibold">{{ item.title }}</h3>
            </div>
            <span class="rounded-full px-3 py-1 text-xs font-semibold" style="background: var(--primary-soft); color: var(--primary)">
              {{ toLabel(item.status, listingStatusLabels) }}
            </span>
          </div>
          <p class="mt-2 text-sm muted">{{ item.categoryName || '未分类' }} · {{ formatPrice(item.price) }}</p>
          <p class="mt-1 text-sm muted">{{ item.location }}</p>
          <div class="mt-4 flex gap-2">
            <button class="btn-secondary flex-1" @click="editListing(item)">编辑</button>
            <button
              v-if="item.status === 'PUBLISHED'"
              class="btn-secondary flex-1"
              @click="changeStatus(item, 'OFFLINE')"
            >
              下架
            </button>
            <button
              v-else
              class="btn-primary flex-1"
              @click="changeStatus(item, 'PUBLISHED')"
            >
              重新上架
            </button>
          </div>
        </div>
      </div>

      <EmptyState v-else class="mt-4" title="还没有发布内容" description="先创建一条技能服务、闲置物品或求助信息，方便演示完整流程。" />
    </section>
  </div>
</template>
