<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { api } from '../api/services'
import EmptyState from '../components/EmptyState.vue'
import StatusBanner from '../components/StatusBanner.vue'
import { certificationStatusLabels } from '../constants/labels'
import { useAuthStore } from '../stores/auth'
import type { Certification, NotificationItem } from '../types'
import { formatTime, readError, toLabel } from '../utils/format'
import { requireText } from '../utils/validate'

const authStore = useAuthStore()
const router = useRouter()
const profileForm = reactive({
  avatarUrl: '',
  nickname: '',
  department: '',
  gradeLevel: '',
  bio: '',
  tradeLocation: '',
})
const certificationForm = reactive({
  realName: '',
  studentCardImage: '',
})
const certification = ref<Certification | null>(null)
const notifications = ref<NotificationItem[]>([])
const message = ref('')
const errorText = ref('')

const syncForm = () => {
  profileForm.avatarUrl = authStore.user?.avatarUrl ?? ''
  profileForm.nickname = authStore.user?.nickname ?? ''
  profileForm.department = authStore.user?.department ?? ''
  profileForm.gradeLevel = authStore.user?.gradeLevel ?? ''
  profileForm.bio = authStore.user?.bio ?? ''
  profileForm.tradeLocation = authStore.user?.tradeLocation ?? ''
}

const load = async () => {
  try {
    await authStore.refreshMe()
    syncForm()
    certification.value = await api.myCertification()
    notifications.value = await api.notifications()
  } catch (error) {
    errorText.value = readError(error)
  }
}

onMounted(load)

const saveProfile = async () => {
  message.value = ''
  errorText.value = ''
  try {
    requireText(profileForm.nickname, '昵称不能为空')
    const user = await api.updateProfile(profileForm)
    authStore.setUser(user)
    syncForm()
    message.value = '资料已保存。'
  } catch (error) {
    errorText.value = readError(error)
  }
}

const submitCertification = async () => {
  message.value = ''
  errorText.value = ''
  try {
    requireText(certificationForm.realName, '请输入真实姓名')
    requireText(certificationForm.studentCardImage, '请填写学生证图片地址')
    certification.value = await api.submitCertification(certificationForm)
    await authStore.refreshMe()
    message.value = '实名认证申请已提交。'
  } catch (error) {
    errorText.value = readError(error)
  }
}

const logout = async () => {
  try {
    await api.logout()
  } catch {
    // ignore
  }
  authStore.clear()
  router.push('/login')
}

const readAllNotifications = async () => {
  try {
    await api.readAllNotifications()
    notifications.value = notifications.value.map((item) => ({ ...item, read: true }))
    message.value = '消息已全部标记为已读。'
  } catch (error) {
    errorText.value = readError(error)
  }
}
</script>

<template>
  <div class="space-y-4">
    <section class="card rounded-[28px] p-5">
      <div class="flex items-center justify-between">
        <div>
          <h2 class="section-title">{{ authStore.user?.nickname || '未登录用户' }}</h2>
          <p class="mt-1 text-sm muted">认证状态：{{ toLabel(authStore.user?.certificationStatus, certificationStatusLabels) }}</p>
        </div>
        <button class="btn-secondary" @click="logout">退出登录</button>
      </div>
      <div class="mt-4 grid grid-cols-2 gap-3 text-sm">
        <div class="rounded-2xl border p-3" style="border-color: var(--line)">
          <p class="muted">好评均分</p>
          <p class="mt-2 text-xl font-semibold">{{ authStore.user?.averageRating ?? 0 }}</p>
        </div>
        <div class="rounded-2xl border p-3" style="border-color: var(--line)">
          <p class="muted">完成订单</p>
          <p class="mt-2 text-xl font-semibold">{{ authStore.user?.completedOrderCount ?? 0 }}</p>
        </div>
        <div class="rounded-2xl border p-3" style="border-color: var(--line)">
          <p class="muted">当前积分</p>
          <p class="mt-2 text-xl font-semibold">{{ authStore.user?.points ?? 0 }}</p>
        </div>
        <div class="rounded-2xl border p-3" style="border-color: var(--line)">
          <p class="muted">常用地点</p>
          <p class="mt-2 text-sm font-semibold">{{ authStore.user?.tradeLocation || '未填写' }}</p>
        </div>
      </div>
    </section>

    <section class="card rounded-[28px] p-5">
      <h3 class="section-title">个人资料</h3>
      <div class="mt-4 space-y-3">
        <input v-model="profileForm.avatarUrl" class="field" placeholder="头像地址" />
        <input v-model="profileForm.nickname" class="field" placeholder="昵称" />
        <input v-model="profileForm.department" class="field" placeholder="院系" />
        <input v-model="profileForm.gradeLevel" class="field" placeholder="年级" />
        <textarea v-model="profileForm.bio" class="field min-h-[100px]" placeholder="个人简介" />
        <input v-model="profileForm.tradeLocation" class="field" placeholder="常用交易地点" />
      </div>
      <button class="btn-primary mt-4 w-full" @click="saveProfile">保存资料</button>
    </section>

    <section class="card rounded-[28px] p-5">
      <div class="flex items-center justify-between">
        <h3 class="section-title">实名认证</h3>
        <span class="text-sm muted">{{ toLabel(certification?.status || authStore.user?.certificationStatus, certificationStatusLabels) }}</span>
      </div>
      <div class="mt-4 space-y-3">
        <input v-model="certificationForm.realName" class="field" placeholder="真实姓名" />
        <input v-model="certificationForm.studentCardImage" class="field" placeholder="学生证图片地址" />
      </div>
      <p v-if="certification?.remark" class="mt-3 text-sm muted">审核备注：{{ certification.remark }}</p>
      <button class="btn-secondary mt-4 w-full" @click="submitCertification">提交认证</button>
    </section>

    <section class="card rounded-[28px] p-5">
      <div class="flex items-center justify-between">
        <h3 class="section-title">提醒消息</h3>
        <button class="btn-secondary" @click="readAllNotifications">全部已读</button>
      </div>
      <div v-if="notifications.length" class="mt-4 space-y-3">
        <div v-for="item in notifications" :key="item.id" class="rounded-2xl border p-4" style="border-color: var(--line)">
          <div class="flex items-center justify-between gap-3">
            <p class="text-sm font-semibold">{{ item.title }}</p>
            <span class="text-xs muted">{{ item.read ? '已读' : '未读' }}</span>
          </div>
          <p class="mt-2 text-sm muted">{{ item.content }}</p>
          <p class="mt-2 text-xs muted">{{ formatTime(item.createdAt) }}</p>
        </div>
      </div>
      <EmptyState v-else class="mt-4" title="暂无提醒消息" description="订单确认、完成、评价、认证审核等操作都会在这里留下提醒。" />
    </section>

    <StatusBanner v-if="message" type="success" :text="message" />
    <StatusBanner v-if="errorText" type="error" :text="errorText" />
  </div>
</template>
