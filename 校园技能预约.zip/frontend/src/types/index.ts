export interface ApiResponse<T> {
  success: boolean
  message: string
  data: T
}

export interface UserProfile {
  id: number
  studentId: string
  phone: string
  nickname: string
  avatarUrl?: string | null
  department?: string | null
  gradeLevel?: string | null
  bio?: string | null
  tradeLocation?: string | null
  points: number
  disabled: boolean
  certificationStatus: string
  averageRating: number
  completedOrderCount: number
}

export interface AuthSession {
  token: string
  role: 'USER' | 'ADMIN'
  user: UserProfile
}

export interface Announcement {
  id: number
  title: string
  content: string
  pinned: boolean
  status: string
  publishedAt: string
}

export interface Category {
  id: number
  name: string
  type: 'SKILL' | 'ITEM' | 'HELP'
  enabled?: boolean
  sortOrder?: number
}

export interface Listing {
  id: number
  type: 'SKILL' | 'ITEM' | 'HELP'
  categoryId?: number | null
  categoryName?: string | null
  userId: number
  userNickname: string
  title: string
  description: string
  images?: string | null
  price: number
  stock: number
  location: string
  contact: string
  appointmentTime?: string | null
  status: string
  viewCount: number
  createdAt: string
  updatedAt: string
}

export interface Order {
  id: number
  listingId: number
  listingTitle: string
  listingType: string
  buyerId: number
  sellerId: number
  buyerNickname: string
  sellerNickname: string
  status: string
  note?: string | null
  tradeLocation?: string | null
  contactPhone?: string | null
  handoffMethod?: string | null
  pickupCode?: string | null
  offlinePaid: boolean
  createdAt: string
  confirmedAt?: string | null
  completedAt?: string | null
}

export interface Certification {
  id: number
  userId: number
  userNickname: string
  realName: string
  studentCardImage: string
  status: string
  remark?: string | null
  submittedAt: string
  reviewedAt?: string | null
}

export interface Review {
  id: number
  orderId: number
  reviewerId: number
  revieweeId: number
  reviewerNickname: string
  rating: number
  content: string
  createdAt: string
}

export interface ReportItem {
  id: number
  reporterId: number
  reporterNickname: string
  targetType: string
  targetId: number
  reason: string
  status: string
  handleResult?: string | null
  createdAt: string
  handledAt?: string | null
}

export interface AdminDashboard {
  userCount: number
  listingCount: number
  orderCount: number
  completedOrderCount: number
  pendingCertificationCount: number
  pendingReportCount: number
  listingTypeStats: StatsItem[]
  orderStatusStats: StatsItem[]
  hotCategoryStats: StatsItem[]
  recentListingTrend: StatsTrendPoint[]
  recentOrderTrend: StatsTrendPoint[]
}

export interface StatsItem {
  key: string
  label: string
  total: number
}

export interface StatsTrendPoint {
  date: string
  total: number
}

export interface HomeData {
  announcements: Announcement[]
  featuredListings: Listing[]
  stats: Record<string, number>
}

export interface NotificationItem {
  id: number
  type: string
  title: string
  content: string
  read: boolean
  createdAt: string
}

export interface AdminUser {
  id: number
  studentId: string
  phone: string
  nickname: string
  department?: string | null
  gradeLevel?: string | null
  disabled: boolean
  certificationStatus: string
  createdAt: string
}
